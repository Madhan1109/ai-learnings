# Task 3: Cognitive Services Deployment

## 🎯 Objective
Deploy core Azure Cognitive Services (Speech, Vision, and Document Intelligence) using Infrastructure as Code (Bicep) templates, ensuring secure configuration and proper integration with your Key Vault.

## ⏱️ Estimated Time: 2 hours

## 📋 Prerequisites
- Completed Task 1 (Resource Group & Key Vault setup)
- Completed Task 2 (Development tools installation)
- Azure CLI authenticated and working
- Bicep CLI installed and functional

## 🔧 Step-by-Step Instructions

### Step 1: Create Bicep Template Structure

1. **Create the main Bicep file**:
   - Navigate to your `deliverables` folder
   - Create a new file named `cognitive-services.bicep`

2. **Set up the basic template structure**:
   ```bicep
   @description('Location for all resources')
   param location string = resourceGroup().location
   
   @description('Base name for all resources')
   param baseName string = 'foundry'
   
   @description('Your unique identifier (e.g., your name or initials)')
   param uniqueId string
   
   @description('Key Vault name from Task 1')
   param keyVaultName string
   
   @description('SKU for Cognitive Services')
   @allowed(['F0', 'S0', 'S1'])
   param cognitiveServicesSku string = 'S0'
   
   // Variables
   var speechServiceName = '${baseName}-speech-${uniqueId}'
   var visionServiceName = '${baseName}-vision-${uniqueId}'
   var documentIntelligenceName = '${baseName}-docint-${uniqueId}'
   ```

### Step 2: Define Cognitive Services Resources

Add the following resources to your Bicep template:

1. **Speech Service**:
   ```bicep
   // Speech Service
   resource speechService 'Microsoft.CognitiveServices/accounts@2023-05-01' = {
     name: speechServiceName
     location: location
     sku: {
       name: cognitiveServicesSku
     }
     kind: 'SpeechServices'
     properties: {
       apiProperties: {}
       customSubDomainName: speechServiceName
       networkAcls: {
         defaultAction: 'Allow'
         virtualNetworkRules: []
         ipRules: []
       }
       publicNetworkAccess: 'Enabled'
     }
     tags: {
       Environment: 'Learning'
       Project: 'Azure-AI-Foundry'
       Week: '1'
     }
   }
   ```

2. **Computer Vision Service**:
   ```bicep
   // Computer Vision Service
   resource visionService 'Microsoft.CognitiveServices/accounts@2023-05-01' = {
     name: visionServiceName
     location: location
     sku: {
       name: cognitiveServicesSku
     }
     kind: 'ComputerVision'
     properties: {
       apiProperties: {}
       customSubDomainName: visionServiceName
       networkAcls: {
         defaultAction: 'Allow'
         virtualNetworkRules: []
         ipRules: []
       }
       publicNetworkAccess: 'Enabled'
     }
     tags: {
       Environment: 'Learning'
       Project: 'Azure-AI-Foundry'
       Week: '1'
     }
   }
   ```

3. **Document Intelligence Service**:
   ```bicep
   // Document Intelligence Service
   resource documentIntelligence 'Microsoft.CognitiveServices/accounts@2023-05-01' = {
     name: documentIntelligenceName
     location: location
     sku: {
       name: cognitiveServicesSku
     }
     kind: 'FormRecognizer'
     properties: {
       apiProperties: {}
       customSubDomainName: documentIntelligenceName
       networkAcls: {
         defaultAction: 'Allow'
         virtualNetworkRules: []
         ipRules: []
       }
       publicNetworkAccess: 'Enabled'
     }
     tags: {
       Environment: 'Learning'
       Project: 'Azure-AI-Foundry'
       Week: '1'
     }
   }
   ```

### Step 3: Add Key Vault Integration

1. **Reference existing Key Vault**:
   ```bicep
   // Reference to existing Key Vault
   resource keyVault 'Microsoft.KeyVault/vaults@2023-07-01' existing = {
     name: keyVaultName
   }
   ```

2. **Store service keys in Key Vault**:
   ```bicep
   // Store Speech Service key in Key Vault
   resource speechServiceKeySecret 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
     parent: keyVault
     name: 'speech-service-key'
     properties: {
       value: speechService.listKeys().key1
     }
   }
   
   // Store Vision Service key in Key Vault
   resource visionServiceKeySecret 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
     parent: keyVault
     name: 'vision-service-key'
     properties: {
       value: visionService.listKeys().key1
     }
   }
   
   // Store Document Intelligence key in Key Vault
   resource documentIntelligenceKeySecret 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
     parent: keyVault
     name: 'document-intelligence-key'
     properties: {
       value: documentIntelligence.listKeys().key1
     }
   }
   
   // Store service endpoints in Key Vault
   resource speechServiceEndpointSecret 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
     parent: keyVault
     name: 'speech-service-endpoint'
     properties: {
       value: speechService.properties.endpoint
     }
   }
   
   resource visionServiceEndpointSecret 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
     parent: keyVault
     name: 'vision-service-endpoint'
     properties: {
       value: visionService.properties.endpoint
     }
   }
   
   resource documentIntelligenceEndpointSecret 'Microsoft.KeyVault/vaults/secrets@2023-07-01' = {
     parent: keyVault
     name: 'document-intelligence-endpoint'
     properties: {
       value: documentIntelligence.properties.endpoint
     }
   }
   ```

### Step 4: Add Outputs

```bicep
// Outputs
output speechServiceName string = speechService.name
output speechServiceEndpoint string = speechService.properties.endpoint
output visionServiceName string = visionService.name
output visionServiceEndpoint string = visionService.properties.endpoint
output documentIntelligenceName string = documentIntelligence.name
output documentIntelligenceEndpoint string = documentIntelligence.properties.endpoint
```

### Step 5: Deploy the Bicep Template

1. **Create a parameters file** (`cognitive-services.parameters.json`):
   ```json
   {
     "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#",
     "contentVersion": "1.0.0.0",
     "parameters": {
       "uniqueId": {
         "value": "yourname"
       },
       "keyVaultName": {
         "value": "foundry-kv-yourname"
       },
       "cognitiveServicesSku": {
         "value": "S0"
       }
     }
   }
   ```

2. **Deploy using Azure CLI**:
   ```bash
   # Navigate to your deliverables folder
   cd docs/week1/deliverables
   
   # Deploy the template
   az deployment group create \
     --resource-group "Foundry-RG" \
     --template-file "cognitive-services.bicep" \
     --parameters "@cognitive-services.parameters.json"
   ```

3. **Monitor the deployment**:
   ```bash
   # Check deployment status
   az deployment group list --resource-group "Foundry-RG" --output table
   ```

### Step 6: Verify Deployment

1. **Check resources in Azure Portal**:
   - Navigate to your "Foundry-RG" resource group
   - Verify all three Cognitive Services are listed
   - Check that each service shows "Succeeded" status

2. **Verify Key Vault secrets**:
   ```bash
   # List secrets in Key Vault
   az keyvault secret list --vault-name "foundry-kv-yourname" --output table
   ```

3. **Test service endpoints**:
   ```bash
   # Get Speech Service details
   az cognitiveservices account show \
     --name "foundry-speech-yourname" \
     --resource-group "Foundry-RG"
   ```

## 📝 Documentation Requirements

Create a file `deliverables/task3-documentation.md` with the following information:

```markdown
# Task 3: Cognitive Services Deployment Documentation

## Deployment Details
- **Deployment Date**: [Current date]
- **Resource Group**: Foundry-RG
- **Bicep Template**: cognitive-services.bicep
- **Parameters File**: cognitive-services.parameters.json

## Deployed Services

### Speech Service
- **Name**: foundry-speech-[yourname]
- **SKU**: S0
- **Endpoint**: [Service endpoint URL]
- **Region**: [Your selected region]
- **Status**: ✅ Deployed successfully

### Computer Vision Service
- **Name**: foundry-vision-[yourname]
- **SKU**: S0
- **Endpoint**: [Service endpoint URL]
- **Region**: [Your selected region]
- **Status**: ✅ Deployed successfully

### Document Intelligence Service
- **Name**: foundry-docint-[yourname]
- **SKU**: S0
- **Endpoint**: [Service endpoint URL]
- **Region**: [Your selected region]
- **Status**: ✅ Deployed successfully

## Key Vault Integration
- **Keys Stored**: ✅ All service keys stored securely
- **Endpoints Stored**: ✅ All service endpoints stored
- **Access Verified**: ✅ Can retrieve secrets successfully

## Deployment Commands Used
```bash
az deployment group create \
  --resource-group "Foundry-RG" \
  --template-file "cognitive-services.bicep" \
  --parameters "@cognitive-services.parameters.json"
```

## Verification Results
- **Azure Portal Check**: ✅ All services visible and running
- **CLI Verification**: ✅ All services accessible via CLI
- **Key Vault Secrets**: ✅ All keys and endpoints stored
- **Service Health**: ✅ All services reporting healthy status

## Cost Estimation
- **Speech Service (S0)**: ~$1/1000 transactions
- **Vision Service (S0)**: ~$1/1000 transactions  
- **Document Intelligence (S0)**: ~$1.50/1000 pages
- **Estimated Monthly Cost**: $10-20 for learning activities
```

## 📸 Screenshots to Capture

Save screenshots in `deliverables/screenshots/task3/`:

1. **Bicep Template**: Screenshot of your completed .bicep file
2. **Deployment Success**: Screenshot of successful deployment in CLI
3. **Resource Group**: Screenshot showing all three services in Azure Portal
4. **Service Details**: Screenshots of each service's overview page
5. **Key Vault Secrets**: Screenshot showing stored keys and endpoints
6. **Service Health**: Screenshot of service health status

## ✅ Validation Checklist

Before proceeding to Task 4, ensure:

- [ ] Bicep template is complete and syntactically correct
- [ ] Parameters file is configured with your unique values
- [ ] Deployment completed successfully without errors
- [ ] All three Cognitive Services are visible in Azure Portal
- [ ] All services show "Succeeded" deployment status
- [ ] Service keys are stored in Key Vault
- [ ] Service endpoints are stored in Key Vault
- [ ] You can retrieve secrets from Key Vault via CLI
- [ ] Documentation is complete with all service details
- [ ] Screenshots are captured and organized

## 🚨 Troubleshooting

### Common Issues and Solutions:

**Issue**: Bicep compilation errors
- **Solution**: 
  1. Check syntax using `az bicep build --file cognitive-services.bicep`
  2. Verify all resource names are unique
  3. Ensure proper indentation and brackets

**Issue**: Deployment fails with quota exceeded
- **Solution**: 
  1. Try a different region with available quota
  2. Use F0 (free tier) instead of S0 for learning
  3. Check your subscription limits

**Issue**: Key Vault access denied during deployment
- **Solution**: 
  1. Verify your user has Key Vault Contributor role
  2. Check Key Vault access policies
  3. Ensure Key Vault allows access from your IP

**Issue**: Service names already exist
- **Solution**: 
  1. Cognitive Service names must be globally unique
  2. Add more unique identifiers to your names
  3. Try different combinations in parameters file

**Issue**: Region not supported for certain services
- **Solution**: 
  1. Check service availability by region
  2. Use East US or West Europe for best compatibility
  3. Verify all services support your chosen region

## 📚 Additional Resources

- [Bicep Documentation](https://docs.microsoft.com/azure/azure-resource-manager/bicep/)
- [Cognitive Services Documentation](https://docs.microsoft.com/azure/cognitive-services/)
- [Azure Speech Service](https://docs.microsoft.com/azure/cognitive-services/speech-service/)
- [Computer Vision API](https://docs.microsoft.com/azure/cognitive-services/computer-vision/)
- [Document Intelligence](https://docs.microsoft.com/azure/applied-ai-services/form-recognizer/)

## ➡️ Next Step

Once you've completed this task and all services are deployed successfully, proceed to [Task 4: Service Testing & Validation](task4-service-testing.md).

---

**💡 Pro Tip**: Keep your service endpoints and keys secure - never commit them to version control!