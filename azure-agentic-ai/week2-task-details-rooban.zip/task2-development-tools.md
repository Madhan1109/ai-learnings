# Task 2: Development Tools Installation

## 🎯 Objective
Install and configure the essential development tools needed for Azure AI Foundry development, including Azure CLI, Azure Developer CLI, and Bicep.

## ⏱️ Estimated Time: 1 hour

## 📋 Prerequisites
- Administrative access to your development machine
- Internet connection for downloading tools
- Completed Task 1 (Resource Group & Key Vault setup)

## 🔧 Step-by-Step Instructions

### Step 1: Install Azure CLI

#### For Windows:
1. **Download Azure CLI**:
   - Visit [https://aka.ms/installazurecliwindows](https://aka.ms/installazurecliwindows)
   - Download the MSI installer
   - Run the installer with administrator privileges
   - Follow the installation wizard (use default settings)

2. **Verify Installation**:
   - Open Command Prompt or PowerShell as Administrator
   - Run: `az --version`
   - You should see version 2.50.0 or later

#### For macOS:
1. **Install using Homebrew** (recommended):
   ```bash
   brew update && brew install azure-cli
   ```

2. **Alternative - Direct Download**:
   - Visit [https://aka.ms/installazureclimacos](https://aka.ms/installazureclimacos)
   - Download and run the installer

#### For Linux (Ubuntu/Debian):
```bash
curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash
```

### Step 2: Install Azure Developer CLI (azd)

#### For Windows:
1. **Using PowerShell** (recommended):
   ```powershell
   powershell -ex AllSigned -c "Invoke-RestMethod 'https://aka.ms/install-azd.ps1' | Invoke-Expression"
   ```

2. **Using Winget**:
   ```cmd
   winget install microsoft.azd
   ```

#### For macOS:
```bash
brew tap azure/azd && brew install azd
```

#### For Linux:
```bash
curl -fsSL https://aka.ms/install-azd.sh | bash
```

### Step 3: Install Bicep CLI

#### For Windows:
1. **Using Azure CLI** (recommended):
   ```cmd
   az bicep install
   ```

2. **Manual Installation**:
   - Download from [GitHub Releases](https://github.com/Azure/bicep/releases)
   - Add to your PATH environment variable

#### For macOS:
```bash
# Using Azure CLI
az bicep install

# Or using Homebrew
brew install bicep
```

#### For Linux:
```bash
# Using Azure CLI
az bicep install

# Or manual installation
curl -Lo bicep https://github.com/Azure/bicep/releases/latest/download/bicep-linux-x64
chmod +x ./bicep
sudo mv ./bicep /usr/local/bin/bicep
```

### Step 4: Install Python and Jupyter

#### For Windows:
1. **Download Python**:
   - Visit [https://www.python.org/downloads/](https://www.python.org/downloads/)
   - Download Python 3.10 or later
   - During installation, check "Add Python to PATH"

2. **Install Jupyter**:
   ```cmd
   pip install jupyter notebook ipykernel
   ```

#### For macOS:
```bash
# Using Homebrew
brew install python@3.10
pip3 install jupyter notebook ipykernel
```

#### For Linux:
```bash
sudo apt update
sudo apt install python3.10 python3-pip
pip3 install jupyter notebook ipykernel
```

### Step 5: Configure Azure CLI Authentication

1. **Login to Azure**:
   ```bash
   az login
   ```
   - This will open a web browser for authentication
   - Sign in with your Azure account
   - Close the browser when authentication is complete

2. **Set Default Subscription** (if you have multiple):
   ```bash
   az account list --output table
   az account set --subscription "Your Subscription Name"
   ```

3. **Verify Authentication**:
   ```bash
   az account show
   ```
   - This should display your current subscription details

### Step 6: Configure Azure Developer CLI

1. **Login to Azure Developer CLI**:
   ```bash
   azd auth login
   ```
   - Follow the same authentication process as Azure CLI

2. **Verify azd Installation**:
   ```bash
   azd version
   ```
   - Should show version 1.0.0 or later

### Step 7: Verify Bicep Installation

1. **Check Bicep Version**:
   ```bash
   az bicep version
   ```
   - Should show version 0.23.1 or later

2. **Test Bicep Compilation**:
   ```bash
   az bicep build --help
   ```
   - Should display help information without errors

## 📝 Documentation Requirements

Create a file `deliverables/versions.md` with the following information:

```markdown
# Development Tools Version Documentation

## Installation Date
**Date**: [Current date]
**Operating System**: [Your OS - Windows 11, macOS Ventura, Ubuntu 22.04, etc.]

## Tool Versions

### Azure CLI
- **Version**: [Output of `az --version`]
- **Installation Method**: [MSI/Homebrew/apt/etc.]
- **Installation Status**: ✅ Success

### Azure Developer CLI (azd)
- **Version**: [Output of `azd version`]
- **Installation Method**: [PowerShell/Homebrew/curl/etc.]
- **Installation Status**: ✅ Success

### Bicep CLI
- **Version**: [Output of `az bicep version`]
- **Installation Method**: [Azure CLI/Homebrew/Manual/etc.]
- **Installation Status**: ✅ Success

### Python
- **Version**: [Output of `python --version`]
- **Installation Method**: [Official installer/Homebrew/apt/etc.]
- **Installation Status**: ✅ Success

### Jupyter Notebook
- **Version**: [Output of `jupyter --version`]
- **Installation Method**: pip/pip3
- **Installation Status**: ✅ Success

## Authentication Status

### Azure CLI
- **Login Status**: ✅ Authenticated
- **Default Subscription**: [Your subscription name]
- **Account**: [Your Azure account email]

### Azure Developer CLI
- **Login Status**: ✅ Authenticated
- **Account**: [Your Azure account email]

## Verification Tests

### Azure CLI Test
```bash
Command: az group list --query "[?name=='Foundry-RG']"
Result: ✅ Successfully listed resource group
```

### Bicep Test
```bash
Command: az bicep build --help
Result: ✅ Help displayed without errors
```

### Python/Jupyter Test
```bash
Command: jupyter --version
Result: ✅ Version information displayed
```

## Environment Variables
- **PATH includes Azure CLI**: ✅ Yes
- **PATH includes Python**: ✅ Yes
- **PATH includes Bicep**: ✅ Yes (via Azure CLI)
```

## 🧪 Validation Tests

Run these commands to verify everything is working:

### Test 1: Azure CLI Connectivity
```bash
az group show --name "Foundry-RG"
```
**Expected Result**: Details of your resource group from Task 1

### Test 2: Key Vault Access
```bash
az keyvault secret list --vault-name "foundry-kv-[yourname]"
```
**Expected Result**: List showing your test secret

### Test 3: Bicep Functionality
```bash
az bicep build --help
```
**Expected Result**: Help text without errors

### Test 4: Python and Jupyter
```bash
python --version
jupyter --version
```
**Expected Result**: Version numbers for both tools

### Test 5: Azure Developer CLI
```bash
azd version
azd auth login --check-status
```
**Expected Result**: Version info and authentication confirmation

## 📸 Screenshots to Capture

Save screenshots in `deliverables/screenshots/task2/`:

1. **Azure CLI Version**: Screenshot of `az --version` output
2. **Authentication Success**: Screenshot of `az account show` output
3. **Bicep Version**: Screenshot of `az bicep version` output
4. **Python/Jupyter Versions**: Screenshot of version commands
5. **azd Status**: Screenshot of `azd version` and auth status

## ✅ Validation Checklist

Before proceeding to Task 3, ensure:

- [ ] Azure CLI version 2.50.0 or later is installed
- [ ] Azure Developer CLI version 1.0.0 or later is installed
- [ ] Bicep CLI version 0.23.1 or later is installed
- [ ] Python 3.10 or later is installed
- [ ] Jupyter Notebook is installed and working
- [ ] Azure CLI authentication is successful
- [ ] Azure Developer CLI authentication is successful
- [ ] You can access your Foundry-RG resource group via CLI
- [ ] You can list secrets in your Key Vault via CLI
- [ ] All version information is documented in `versions.md`

## 🚨 Troubleshooting

### Common Issues and Solutions:

**Issue**: Azure CLI installation fails on Windows
- **Solution**: Run installer as Administrator, disable antivirus temporarily

**Issue**: `az` command not found after installation
- **Solution**: 
  1. Restart your terminal/command prompt
  2. Check if Azure CLI is in your PATH
  3. On Windows, log out and log back in

**Issue**: Bicep installation fails
- **Solution**: 
  1. Update Azure CLI first: `az upgrade`
  2. Try manual installation from GitHub releases

**Issue**: Python/pip not found
- **Solution**: 
  1. Ensure Python was added to PATH during installation
  2. On Windows, try `py` instead of `python`
  3. Use `python3` and `pip3` on macOS/Linux

**Issue**: Azure authentication fails
- **Solution**: 
  1. Clear browser cache and try again
  2. Use `az login --use-device-code` for alternative auth method
  3. Check if your organization requires specific authentication methods

**Issue**: Permission denied errors on macOS/Linux
- **Solution**: Use `sudo` for system-wide installations or install to user directory

## 📚 Additional Resources

- [Azure CLI Documentation](https://docs.microsoft.com/cli/azure/)
- [Azure Developer CLI Documentation](https://docs.microsoft.com/azure/developer/azure-developer-cli/)
- [Bicep Documentation](https://docs.microsoft.com/azure/azure-resource-manager/bicep/)
- [Python Installation Guide](https://www.python.org/downloads/)
- [Jupyter Documentation](https://jupyter.org/documentation)

## ➡️ Next Step

Once you've completed this task and all tools are working correctly, proceed to [Task 3: Cognitive Services Deployment](task3-cognitive-services.md).

---

**💡 Pro Tip**: Keep your terminal/command prompt open - you'll be using these tools extensively in the next tasks! 