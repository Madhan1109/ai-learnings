# Task 4: Explore Services Through Simple Scenarios

## 🎯 Objective
Explore your deployed Cognitive Services through practical, hands-on scenarios to understand what each service does and how it works, focusing on learning and discovery rather than technical validation.

## ⏱️ Estimated Time: 1.5 hours

## 📋 Prerequisites
- Completed Task 3 (Cognitive Services deployment)
- Python and Jupyter Notebook installed
- Azure CLI authenticated
- All service keys stored in Key Vault

## 🔧 Step-by-Step Learning Scenarios

### Step 1: Set Up Learning Environment

1. **Install required packages**:
   ```bash
   pip install requests azure-keyvault-secrets azure-identity
   ```

2. **Create a learning notebook**:
   - Navigate to your `deliverables` folder
   - Create a new Jupyter notebook named `cognitive_services_exploration.ipynb`
   - This will help you interactively explore each service

### Step 2: 🔊 Speech Service Scenario - "Make Your Computer Talk"

**Scenario**: Convert text to speech and understand how AI voices work.

1. **Set up credentials retrieval**:
   ```python
   import requests
   import json
   from azure.identity import DefaultAzureCredential
   from azure.keyvault.secrets import SecretClient
   
   # Replace with your Key Vault name
   KEY_VAULT_NAME = "foundry-kv-yourname"
   KEY_VAULT_URL = f"https://{KEY_VAULT_NAME}.vault.azure.net/"
   
   credential = DefaultAzureCredential()
   secret_client = SecretClient(vault_url=KEY_VAULT_URL, credential=credential)
   
   # Get Speech Service credentials
   speech_key = secret_client.get_secret("speech-service-key").value
   speech_endpoint = secret_client.get_secret("speech-service-endpoint").value
   
   print(f"✅ Connected to Speech Service at: {speech_endpoint}")
   ```

2. **Explore available voices**:
   ```python
   # Discover what voices are available
   headers = {
       'Ocp-Apim-Subscription-Key': speech_key,
   }
   
   voices_url = f"{speech_endpoint}/cognitiveservices/v1.0/voices/list"
   response = requests.get(voices_url, headers=headers)
   
   if response.status_code == 200:
       voices = response.json()
       print(f"🎤 Found {len(voices)} available voices!")
       
       # Show some interesting voices
       english_voices = [v for v in voices if v['Locale'].startswith('en-')]
       print(f"\n🇺🇸 English voices available: {len(english_voices)}")
       
       for voice in english_voices[:5]:  # Show first 5
           print(f"   - {voice['DisplayName']} ({voice['Gender']}) - {voice['LocaleName']}")
   ```

3. **Convert text to speech**:
   ```python
   # Create a personalized message
   your_message = "Hello! I'm learning about Azure AI services. This is my computer speaking to me using artificial intelligence!"
   
   # Choose a voice (you can change this)
   selected_voice = "en-US-JennyNeural"  # Female voice
   
   # Prepare the SSML (Speech Synthesis Markup Language)
   ssml = f"""
   <speak version='1.0' xml:lang='en-US'>
       <voice name='{selected_voice}'>
           <prosody rate='medium' pitch='medium'>
               {your_message}
           </prosody>
       </voice>
   </speak>
   """
   
   # Convert to speech
   tts_url = f"{speech_endpoint}/cognitiveservices/v1.0/synthesize"
   headers = {
       'Ocp-Apim-Subscription-Key': speech_key,
       'Content-Type': 'application/ssml+xml',
       'X-Microsoft-OutputFormat': 'audio-16khz-128kbitrate-mono-mp3'
   }
   
   response = requests.post(tts_url, headers=headers, data=ssml.encode('utf-8'))
   
   if response.status_code == 200:
       # Save the audio file
       with open('my_ai_speech.mp3', 'wb') as audio_file:
           audio_file.write(response.content)
       print("🎵 Success! Your AI speech is saved as 'my_ai_speech.mp3'")
       print("   Play this file to hear your computer speak!")
   else:
       print(f"❌ Speech synthesis failed: {response.status_code}")
   ```

**🎯 Learning Questions**:
- How many different voices are available?
- What happens when you change the voice name?
- Try changing the prosody rate to 'slow' or 'fast' - what difference do you notice?

### Step 3: 👁️ Computer Vision Scenario - "What Does AI See?"

**Scenario**: Upload a photo and discover what the AI can "see" and understand about it.

1. **Set up Computer Vision**:
   ```python
   # Get Computer Vision credentials
   vision_key = secret_client.get_secret("vision-service-key").value
   vision_endpoint = secret_client.get_secret("vision-service-endpoint").value
   
   print(f"👁️ Connected to Computer Vision at: {vision_endpoint}")
   ```

2. **Analyze a photo from the internet**:
   ```python
   # Let's analyze a famous landmark
   image_url = "https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/New_york_times_square-terabass.jpg/640px-New_york_times_square-terabass.jpg"
   
   analyze_url = f"{vision_endpoint}/vision/v3.2/analyze"
   
   headers = {
       'Ocp-Apim-Subscription-Key': vision_key,
       'Content-Type': 'application/json'
   }
   
   params = {
       'visualFeatures': 'Categories,Description,Tags,Objects,Faces,Color,Adult'
   }
   
   data = {'url': image_url}
   
   response = requests.post(analyze_url, headers=headers, params=params, json=data)
   
   if response.status_code == 200:
       analysis = response.json()
       
       print("🖼️ AI Analysis Results:")
       print("=" * 40)
       
       # What does the AI think this image shows?
       if 'description' in analysis:
           captions = analysis['description']['captions']
           print(f"📝 AI Description: {captions[0]['text']}")
           print(f"   Confidence: {captions[0]['confidence']:.2%}")
       
       # What objects can it identify?
       if 'objects' in analysis:
           print(f"\n🎯 Objects detected: {len(analysis['objects'])}")
           for obj in analysis['objects'][:5]:  # Show first 5
               print(f"   - {obj['object']} (confidence: {obj['confidence']:.2%})")
       
       # What tags does it assign?
       if 'tags' in analysis:
           print(f"\n🏷️ Tags assigned: {len(analysis['tags'])}")
           top_tags = [tag['name'] for tag in analysis['tags'][:10]]
           print(f"   Top tags: {', '.join(top_tags)}")
       
       # Dominant colors
       if 'color' in analysis:
           colors = analysis['color']
           print(f"\n🎨 Dominant colors: {', '.join(colors['dominantColors'])}")
           print(f"   Accent color: {colors['accentColor']}")
   
   else:
       print(f"❌ Vision analysis failed: {response.status_code}")
   ```

3. **Try your own image**:
   ```python
   # Try with a different image - maybe a photo of food, animals, or people
   your_image_url = "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Gfp-wisconsin-madison-the-nature-boardwalk.jpg/2560px-Gfp-wisconsin-madison-the-nature-boardwalk.jpg"
   
   # Use the same analysis code above but with your_image_url
   # What different results do you get?
   ```

**🎯 Learning Questions**:
- How accurate are the AI's descriptions?
- What objects can it detect vs. what it misses?
- Try images with people - can it detect faces and estimate ages?

### Step 4: 📄 Document Intelligence Scenario - "Extract Information from Documents"

**Scenario**: Process a document and see how AI can extract structured information.

1. **Set up Document Intelligence**:
   ```python
   # Get Document Intelligence credentials
   doc_key = secret_client.get_secret("document-intelligence-key").value
   doc_endpoint = secret_client.get_secret("document-intelligence-endpoint").value
   
   print(f"📄 Connected to Document Intelligence at: {doc_endpoint}")
   ```

2. **Explore available models**:
   ```python
   # See what pre-built models are available
   models_url = f"{doc_endpoint}/formrecognizer/info?api-version=2023-07-31"
   
   headers = {
       'Ocp-Apim-Subscription-Key': doc_key,
   }
   
   response = requests.get(models_url, headers=headers)
   
   if response.status_code == 200:
       info = response.json()
       print("📋 Available Document Models:")
       print(f"   Service Version: {info.get('serviceVersion', 'Unknown')}")
       
       # List some common prebuilt models
       common_models = [
           "prebuilt-layout",
           "prebuilt-document", 
           "prebuilt-receipt",
           "prebuilt-invoice",
           "prebuilt-businessCard"
       ]
       
       print("\n🏗️ Pre-built models you can use:")
       for model in common_models:
           print(f"   - {model}")
   ```

3. **Analyze a simple document**:
   ```python
   # Let's analyze a simple document layout
   document_url = "https://raw.githubusercontent.com/Azure-Samples/cognitive-services-REST-api-samples/master/curl/form-recognizer/sample-layout.pdf"
   
   # Start the analysis
   analyze_url = f"{doc_endpoint}/formrecognizer/documentModels/prebuilt-layout:analyze?api-version=2023-07-31"
   
   headers = {
       'Ocp-Apim-Subscription-Key': doc_key,
       'Content-Type': 'application/json'
   }
   
   data = {
       'urlSource': document_url
   }
   
   response = requests.post(analyze_url, headers=headers, json=data)
   
   if response.status_code == 202:
       # Get the operation location to check results
       operation_location = response.headers['Operation-Location']
       print("📊 Document analysis started...")
       print(f"   Check results at: {operation_location}")
       
       # Wait a moment and check results
       import time
       time.sleep(5)
       
       result_response = requests.get(operation_location, headers={'Ocp-Apim-Subscription-Key': doc_key})
       
       if result_response.status_code == 200:
           result = result_response.json()
           
           if result['status'] == 'succeeded':
               print("✅ Document analysis completed!")
               
               # Show what was extracted
               analyze_result = result['analyzeResult']
               
               print(f"\n📄 Document has {len(analyze_result['pages'])} page(s)")
               
               # Show extracted text
               if 'content' in analyze_result:
                   content = analyze_result['content']
                   print(f"\n📝 Extracted text (first 200 characters):")
                   print(f"   {content[:200]}...")
               
               # Show tables if found
               if 'tables' in analyze_result:
                   print(f"\n📊 Found {len(analyze_result['tables'])} table(s)")
                   for i, table in enumerate(analyze_result['tables']):
                       print(f"   Table {i+1}: {table['rowCount']} rows, {table['columnCount']} columns")
           else:
               print(f"⏳ Analysis status: {result['status']}")
       
   else:
       print(f"❌ Document analysis failed: {response.status_code}")
   ```

**🎯 Learning Questions**:
- What types of information can Document Intelligence extract?
- How does it handle different document formats?
- What's the difference between layout analysis and specialized models (like receipts)?

### Step 5: 🎉 Reflection and Documentation

Document your learning experience and insights from each scenario.

## 📝 Documentation Requirements

Create these files in your `deliverables` folder:
1. `cognitive_services_exploration.ipynb` - Your interactive exploration notebook
2. `my_ai_learning_journey.md` - Your personal reflections and discoveries
3. `my_ai_speech.mp3` - The audio file you generated (if successful)

## 📸 Screenshots to Capture

Save screenshots in `deliverables/screenshots/task4/`:
1. **Speech Service**: List of available voices
2. **Computer Vision**: Analysis results of your chosen image
3. **Document Intelligence**: Extracted information from a document
4. **Your Reflections**: Your completed learning journey document

## ✅ Validation Checklist

Before proceeding to Task 5, ensure:

- [ ] Successfully connected to all three Cognitive Services
- [ ] Generated speech audio from text
- [ ] Analyzed at least 2 different images with Computer Vision
- [ ] Processed a document with Document Intelligence
- [ ] Documented your learning experience and insights
- [ ] All screenshots are captured and organized
- [ ] Reflected on potential real-world applications

## 🚨 Troubleshooting

### Common Issues and Solutions:

**Issue**: Can't retrieve secrets from Key Vault
- **Solution**: 
  1. Ensure you're authenticated with `az login`
  2. Check that your Key Vault name is correct
  3. Verify you have access permissions to the Key Vault

**Issue**: Speech synthesis fails
- **Solution**: 
  1. Check that your SSML format is correct
  2. Try a different voice name from the available list
  3. Ensure your endpoint URL doesn't have extra slashes

**Issue**: Computer Vision analysis fails
- **Solution**: 
  1. Verify the image URL is publicly accessible
  2. Try a different image format (JPG, PNG)
  3. Check that the image isn't too large (< 4MB)

**Issue**: Document Intelligence takes too long
- **Solution**: 
  1. Document processing is asynchronous - wait longer
  2. Check the operation status URL multiple times
  3. Try with a simpler/smaller document

## 📚 Additional Resources

- [Azure Speech Service Documentation](https://docs.microsoft.com/azure/cognitive-services/speech-service/)
- [Computer Vision API Documentation](https://docs.microsoft.com/azure/cognitive-services/computer-vision/)
- [Document Intelligence Documentation](https://docs.microsoft.com/azure/applied-ai-services/form-recognizer/)
- [SSML Reference for Speech](https://docs.microsoft.com/azure/cognitive-services/speech-service/speech-synthesis-markup)

## ➡️ Next Step

Once you've explored all three services and documented your learning journey, proceed to [Task 5: Deploy Azure AI Foundry Chat Template](task5-azure-ai-foundry-chat.md).

---

**💡 Pro Tip**: This hands-on exploration gives you a foundation for understanding how AI services work in practice - you'll use these insights throughout the rest of the program! 