# Task 5: Deploy Azure AI Foundry Chat Template

## 🎯 Objective
Deploy and explore a complete AI chat application using Azure AI Foundry's template-based deployment system, learning how modern AI applications are structured and deployed on Azure.

## ⏱️ Estimated Time: 1.5 hours

## 📋 Prerequisites
- Completed Tasks 1-4 (Infrastructure and services deployed)
- Azure subscription with sufficient quota for AI models
- PowerShell 7.0 or later (required for Azure Developer CLI)
- Azure Developer CLI (azd) installed
- Git installed on your local machine
- Web browser for Azure Portal access

## 🔧 Step-by-Step Instructions

### Step 1: Set Up Development Environment

1. **Install PowerShell 7** (if not already installed):
   ```powershell
   # Windows (using winget)
   winget install Microsoft.PowerShell
   
   # Or download from: https://github.com/PowerShell/PowerShell/releases
   ```
   
   **Verify PowerShell 7 Installation**:
   ```powershell
   $PSVersionTable.PSVersion
   # Should show version 7.0 or higher
   ```

2. **Install Azure Developer CLI (azd)**:
   ```powershell
   # Windows (PowerShell 7)
   winget install microsoft.azd
   
   # Or download from: https://aka.ms/install-azd
   ```

3. **Verify Installation**:
   ```powershell
   azd version
   ```

4. **Login to Azure**:
   ```powershell
   azd auth login
   ```

### Step 2: Clone the AI Chat Template

1. **Clone the Repository**:
   ```powershell
   # Clone the official Azure AI Chat sample
   git clone https://github.com/Azure-Samples/get-started-with-ai-chat.git
   cd get-started-with-ai-chat
   ```

2. **Explore the Template Structure**:
   - `src/` - Application source code (Python backend, React frontend)
   - `infra/` - Infrastructure as Code (Bicep templates)
   - `azure.yaml` - Azure Developer CLI configuration
   - `README.md` - Comprehensive deployment guide

3. **Understand the Architecture**:
   - **Azure AI Foundry Hub & Project** - Central AI workspace
   - **Azure AI Services** - GPT-4o-mini and text-embedding models
   - **Azure Container Apps** - Hosts the web application
   - **Azure Key Vault** - Secure credential storage
   - **Azure Storage Account** - Application data storage

### Step 3: Configure and Deploy the Application

1. **Set Environment Name**:
   ```powershell
   # Choose a unique environment name (lowercase, no spaces)
   azd env new your-ai-chat-app
   ```

2. **Optional: Increase Model Quota** (Recommended):
   ```powershell
   # For optimal performance, increase quota to 100k tokens per minute
   azd env set AZURE_AI_CHAT_DEPLOYMENT_CAPACITY 100
   ```

3. **Deploy the Application**:
   ```powershell
   azd up
   ```
   
   **During deployment, you'll be prompted for**:
   - **Subscription**: Select your Azure subscription
   - **Location**: Choose a region with AI model availability (e.g., East US, West Europe)
   - **Resource naming**: Accept defaults or customize

4. **Monitor Deployment Progress**:
   - The deployment takes 7-10 minutes
   - Watch for any errors or warnings
   - Note the endpoint URL provided at completion

### Step 4: Test the Deployed Application

1. **Access the Chat Application**:
   - Open the endpoint URL provided after deployment
   - You should see a modern chat interface
   - The application is now running on Azure Container Apps

2. **Test Basic Chat Functionality**:
   
   **Test Case 1: Simple Greeting**
   ```
   Message: "Hello! How are you today?"
   Expected: Friendly response from the AI assistant
   ```

   **Test Case 2: Ask for Help**
   ```
   Message: "Can you help me understand what this application does?"
   Expected: Explanation of the chat application's capabilities
   ```

   **Test Case 3: Request a Joke**
   ```
   Message: "Tell me a programming joke"
   Expected: AI-generated joke related to programming
   ```

3. **Evaluate the Responses**:
   - Check response time and quality
   - Note the conversational flow
   - Test multiple conversation turns
   - Verify the AI maintains context

### Step 5: Explore Azure AI Foundry Portal

1. **Access Azure AI Foundry**:
   - Navigate to [https://ai.azure.com](https://ai.azure.com)
   - Sign in with your Azure account
   - Find your newly created AI project

2. **Explore the Project Resources**:
   - **Models and Endpoints**: View deployed GPT-4o-mini and text-embedding models
   - **Connections**: See Azure AI Services connections
   - **Deployments**: Monitor your model deployments and usage

3. **Check Application Insights** (Optional):
   - Navigate to your resource group in Azure Portal
   - Open Application Insights resource
   - View telemetry and performance metrics
   - Check for any errors or warnings

4. **Monitor Resource Usage**:
   - Check token consumption in Azure AI Services
   - Monitor Container App performance
   - Review costs in Azure Cost Management

### Step 5.5: Monitor Application Metrics and Performance

Now that your application is deployed, here's how to check various metrics:

#### 🔍 **1. Azure AI Foundry Portal Metrics**

1. **Access Azure AI Foundry**:
   ```powershell
   # Get your project details
   azd show
   ```
   - Navigate to [https://ai.azure.com](https://ai.azure.com)
   - Find your AI project (usually named after your environment)

2. **Model Usage Metrics**:
   - Go to **"Models and Endpoints"** tab
   - Click on your deployed models (GPT-4o-mini, text-embedding-ada-002)
   - View **"Metrics"** section for:
     - Token consumption (input/output tokens)
     - Request count and rate
     - Response latency
     - Error rates

3. **Real-time Monitoring**:
   - Go to **"Monitoring"** or **"Metrics"** section
   - Set time range (last hour, day, week)
   - Monitor live usage as you test the chat application

#### 📊 **2. Azure Portal - Container Apps Metrics**

1. **Find Your Container App**:
   ```powershell
   # List your resource group resources
   az resource list --resource-group rg-[your-environment-name] --output table
   ```

2. **Access Container App Metrics**:
   - Go to [Azure Portal](https://portal.azure.com)
   - Navigate to your resource group (rg-[your-environment-name])
   - Click on your **Container App** resource
   - Go to **"Monitoring" → "Metrics"**

3. **Key Metrics to Monitor**:
   - **CPU Usage**: Shows application performance
   - **Memory Usage**: Memory consumption patterns
   - **Request Count**: Number of HTTP requests
   - **Response Time**: Application response latency
   - **HTTP Status Codes**: Success/error rates

#### 📈 **3. Application Insights - Detailed Telemetry**

1. **Access Application Insights**:
   - In your resource group, click **Application Insights** resource
   - Go to **"Monitoring" → "Metrics"**

2. **Performance Metrics**:
   - **Server Response Time**: How fast your app responds
   - **Server Requests**: Request volume over time
   - **Failed Requests**: Error tracking
   - **Page Views**: User interaction patterns

3. **Live Metrics Stream**:
   - Click **"Live Metrics"** for real-time monitoring
   - Test your chat app and watch metrics update live
   - Monitor CPU, memory, and request rates in real-time

#### 💰 **4. Cost Monitoring**

1. **Azure Cost Management**:
   ```powershell
   # View current costs
   az consumption usage list --output table
   ```

2. **Portal Cost Analysis**:
   - Go to **"Cost Management + Billing"** in Azure Portal
   - Filter by your resource group
   - View costs by service (AI Services, Container Apps, Storage)

3. **Set Up Cost Alerts**:
   - Go to **"Cost Management" → "Cost alerts"**
   - Create budget alerts for your resource group
   - Set thresholds (e.g., alert when cost exceeds $10)

#### 🔧 **5. Quick Metrics Check Commands**

Run these PowerShell commands to get quick insights:

```powershell
# 1. Get deployment status
azd show

# 2. Check resource group resources
az group show --name rg-[your-environment-name]

# 3. List all resources and their status
az resource list --resource-group rg-[your-environment-name] --query "[].{Name:name, Type:type, Location:location}" --output table

# 4. Get Container App status
az containerapp show --name [your-container-app-name] --resource-group rg-[your-environment-name] --query "{Name:name, Status:properties.provisioningState, URL:properties.configuration.ingress.fqdn}"

# 5. Check AI Services usage (if available)
az cognitiveservices account show --name [your-ai-service-name] --resource-group rg-[your-environment-name]
```

#### 📱 **6. Test and Monitor Workflow**

1. **Generate Some Traffic**:
   - Open your chat application
   - Send 10-15 different messages
   - Try various conversation types (questions, requests, etc.)

2. **Check Metrics After Testing**:
   - Wait 2-3 minutes for metrics to populate
   - Refresh your Azure AI Foundry metrics
   - Check Application Insights for request patterns
   - Monitor token usage in AI Services

3. **Create a Metrics Dashboard**:
   - In Azure Portal, go to **"Dashboard"**
   - Click **"New dashboard"**
   - Add tiles for:
     - Container App CPU/Memory
     - AI Services token usage
     - Application Insights response times
     - Cost trends

#### 🎯 **Key Metrics to Track**

| Metric Category | What to Monitor | Where to Find |
|----------------|-----------------|---------------|
| **Performance** | Response time, CPU, Memory | Container Apps Metrics |
| **Usage** | Token consumption, Request count | Azure AI Foundry |
| **Reliability** | Error rates, Success rates | Application Insights |
| **Cost** | Daily spend, Token costs | Cost Management |
| **User Experience** | Page load time, Chat response time | Application Insights |

#### 📋 **Metrics Checklist**

After testing your application, verify you can see:

- [ ] Token usage in Azure AI Foundry (should show recent activity)
- [ ] Container App CPU/Memory usage (should show spikes during testing)
- [ ] Application Insights request count (should match your test interactions)
- [ ] No error messages in any monitoring dashboard
- [ ] Cost tracking shows expected charges
- [ ] Live metrics stream shows real-time activity during testing

### Step 6: Document Your Deployment

1. **Create Deployment Documentation**:
   - Create a file named `ai_chat_deployment.md` in your deliverables folder
   - Document the deployment process and outcomes

2. **Deployment Summary Template**:
   ```markdown
   # Azure AI Foundry Chat Application Deployment
   
   ## Deployment Details
   - **Date**: [Current date]
   - **Environment Name**: [Your environment name]
   - **Azure Subscription**: [Subscription ID]
   - **Resource Group**: rg-[your environment name]
   - **Location**: [Selected region]
   
   ## Deployed Resources
   - Azure AI Foundry Hub
   - Azure AI Project
   - Azure AI Services (GPT-4o-mini, text-embedding-ada-002)
   - Azure Container Apps
   - Azure Key Vault
   - Azure Storage Account
   - Azure Container Registry
   - Application Insights
   
   ## Application Details
   - **Endpoint URL**: [Your app URL]
   - **Model Capacity**: [Token limit per minute]
   - **Deployment Time**: [Time taken]
   
   ## Test Results
   - ✅ Basic chat functionality working
   - ✅ AI responses are contextual and helpful
   - ✅ Application loads quickly
   - ✅ No errors in initial testing
   
   ## Next Steps
   - Explore customization options
   - Test with more complex scenarios
   - Monitor usage and costs
   ```

3. **Save Configuration Information**:
   ```powershell
   # View deployment details
   azd show
   
   # Save environment configuration
   azd env get-values > deployment_config.txt
   ```
## 🧹 Clean Up Resources (Optional)

**⚠️ Important**: Only clean up if you're done experimenting with the application.

1. **Remove All Resources**:
   ```powershell
   azd down
   ```
   
2. **Confirm Resource Deletion**:
   - This will delete the entire resource group
   - Process takes up to 20 minutes
   - Alternatively, delete the resource group from Azure Portal

3. **Verify Cleanup**:
   - Check Azure Portal to ensure resources are removed
   - Monitor for any remaining costs

## 📝 Documentation Requirements

Create a file `deliverables/task5-documentation.md` using the template from Step 6.

## 📸 Screenshots to Capture

Save screenshots in `deliverables/screenshots/task5/`:

1. **Azure Developer CLI**: `azd up` command execution
2. **Deployment Progress**: Resource provisioning in progress
3. **Deployment Complete**: Final deployment success message with endpoint URL
4. **Chat Application**: The deployed chat interface
5. **Chat Testing**: Screenshots of test conversations
6. **Azure AI Foundry Portal**: Your AI project and deployed models
7. **Resource Group**: All deployed resources in Azure Portal

## ✅ Validation Checklist

Before proceeding to Task 6, ensure:

- [ ] Azure Developer CLI is installed and authenticated
- [ ] Successfully cloned the AI chat template repository
- [ ] Deployed the application using `azd up` without errors
- [ ] Chat application is accessible via the provided endpoint URL
- [ ] Tested basic chat functionality with multiple conversations
- [ ] Explored Azure AI Foundry portal and found your project
- [ ] Documented the deployment process and results
- [ ] All screenshots are captured and organized
- [ ] Application is working as expected with good response quality

## 🚨 Troubleshooting

### Common Issues and Solutions:

**Issue**: `azd up` fails with authentication errors
- **Solution**: 
  1. Ensure you're using PowerShell 7 (check with `$PSVersionTable.PSVersion`)
  2. Run `azd auth login` to re-authenticate
  3. Verify you have Contributor permissions on the subscription
  4. Check if your account has access to create resources

**Issue**: Deployment fails due to quota limits
- **Solution**: 
  1. Try a different Azure region with available quota
  2. Request quota increase for Azure OpenAI in Azure Portal
  3. Use `azd down` and retry with a different location

**Issue**: Chat application loads but doesn't respond
- **Solution**: 
  1. Check Azure AI Services deployment status in Azure Portal
  2. Verify model deployments are active in Azure AI Foundry
  3. Check Application Insights for error logs

**Issue**: Deployment takes too long or times out
- **Solution**: 
  1. Check Azure service health status
  2. Try deploying to a different region
  3. Ensure stable internet connection during deployment

## 📚 Additional Resources

- [Azure AI Foundry Documentation](https://learn.microsoft.com/azure/ai-foundry/)
- [Azure Developer CLI Documentation](https://learn.microsoft.com/azure/developer/azure-developer-cli/)
- **[Get Started with AI Chat Template](https://github.com/Azure-Samples/get-started-with-ai-chat)** - Official Azure sample repository
- [Azure AI Services Documentation](https://learn.microsoft.com/azure/ai-services/)
- [Azure Container Apps Documentation](https://learn.microsoft.com/azure/container-apps/)
- [Azure AI Foundry SDK Overview](https://learn.microsoft.com/azure/ai-studio/how-to/develop/sdk-overview)

## ➡️ Next Step

Once you've successfully deployed and tested your AI chat application, proceed to [Task 6: Weekly Reflection](task6-weekly-reflection.md).

---

**💡 Pro Tip**: This template-based approach shows how modern AI applications are built and deployed - it's a great foundation for understanding enterprise AI development! 