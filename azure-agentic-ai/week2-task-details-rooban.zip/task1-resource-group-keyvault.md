# Task 1: Resource Group & Key Vault Setup

## 🎯 Objective
Create a secure foundation for your Azure AI Foundry learning journey by setting up a resource group and Key Vault with private endpoint configuration.

## ⏱️ Estimated Time: 2 hours

## 📋 Prerequisites
- Azure subscription with Contributor or Owner access
- Web browser for Azure Portal access

## 🔧 Step-by-Step Instructions

### Step 1: Sign in to Azure Portal
1. Open your web browser and navigate to [https://portal.azure.com](https://portal.azure.com)
2. Sign in with your Azure account credentials
3. Verify you're in the correct subscription by checking the subscription name in the top-right corner

### Step 2: Create Resource Group
1. **Navigate to Resource Groups**:
   - In the Azure Portal search bar, type "Resource Groups"
   - Click on "Resource groups" from the search results

2. **Create New Resource Group**:
   - Click the "+ Create" button
   - Fill in the following details:
     - **Subscription**: Select your Azure subscription
     - **Resource group name**: `Foundry-RG`
     - **Region**: Choose a region close to you (e.g., East US, West Europe)
   - Click "Review + create"
   - Click "Create" after validation passes

3. **Verify Creation**:
   - Wait for the deployment to complete (usually takes 10-30 seconds)
   - Click "Go to resource group" to verify it was created successfully

### Step 3: Create Key Vault
1. **Navigate to Key Vault Creation**:
   - In the Azure Portal search bar, type "Key Vault"
   - Click on "Key vaults" from the search results
   - Click "+ Create"

2. **Configure Basic Settings**:
   - **Subscription**: Select your Azure subscription
   - **Resource group**: Select "Foundry-RG" (created in Step 2)
   - **Key vault name**: `foundry-kv-[yourname]` (replace [yourname] with your actual name)
   - **Region**: Same region as your resource group
   - **Pricing tier**: Standard
   - **Days to retain deleted vaults**: 90 (default)
   - **Purge protection**: Disabled (for learning purposes)

3. **Configure Access Policy**:
   - Click "Next: Access policy"
   - **Permission model**: Select "Vault access policy"
   - Click "+ Add Access Policy"
   - **Configure from template**: Select "Secret Management"
   - **Select principal**: Click and search for your user account, then select it
   - Click "Add"
   - Your user should now appear in the access policies list

4. **Configure Networking**:
   - Click "Next: Networking"
   - **Connectivity method**: Select "Private endpoint"
   - Click "+ Add private endpoint"
   - Fill in the private endpoint details:
     - **Name**: `foundry-kv-pe`
     - **Region**: Same as your Key Vault
     - **Target sub-resource**: vault
     - **Virtual network**: Create new or select existing (if creating new, use default settings)
     - **Subnet**: Create new or select existing (if creating new, use default settings)
     - **Private DNS integration**: Yes (checked)
     - **Private DNS zone**: Use default
   - Click "OK"

5. **Review and Create**:
   - Click "Next: Tags" (skip tags for now)
   - Click "Next: Review + create"
   - Review all settings
   - Click "Create"

### Step 4: Configure Network Access
1. **Wait for Deployment**:
   - Key Vault deployment typically takes 2-5 minutes
   - Click "Go to resource" when deployment completes

2. **Configure Firewall Settings**:
   - In the Key Vault, navigate to "Networking" in the left menu
   - Under "Firewalls and virtual networks":
     - Select "Allow access from selected networks"
     - Under "IP Networks", click "+ Add your client IP address"
     - This adds your current public IP to the allowed list
   - Click "Save"

### Step 5: Test Key Vault Access
1. **Create a Test Secret**:
   - In the Key Vault, navigate to "Secrets" in the left menu
   - Click "+ Generate/Import"
   - Fill in the details:
     - **Upload options**: Manual
     - **Name**: `test-secret`
     - **Value**: `Hello Azure AI Foundry!`
   - Click "Create"

2. **Verify Secret Creation**:
   - You should see the secret listed in the Secrets section
   - Click on the secret name to view its details
   - This confirms your access is working correctly

## 📝 Documentation Requirements

Create a file `deliverables/task1-documentation.md` with the following information:

```markdown
# Task 1: Resource Group & Key Vault Documentation

## Resource Group Details
- **Name**: Foundry-RG
- **Region**: [Your selected region]
- **Subscription**: [Your subscription name]
- **Creation Date**: [Date created]

## Key Vault Details
- **Name**: foundry-kv-[yourname]
- **Resource Group**: Foundry-RG
- **Region**: [Your selected region]
- **SKU**: Standard
- **URI**: [Key Vault URI from overview page]

## Private Endpoint Configuration
- **Private Endpoint Name**: foundry-kv-pe
- **Virtual Network**: [VNet name]
- **Subnet**: [Subnet name]
- **Private IP**: [Private IP address]

## Access Policies
- **User**: [Your user account]
- **Permissions**: Secret Management (Get, List, Set, Delete, Recover, Backup, Restore)

## Network Configuration
- **Access Method**: Private endpoint + Selected networks
- **Allowed IP Addresses**: [Your public IP]
- **Public Network Access**: Enabled for selected networks

## Test Results
- **Test Secret Created**: ✅ Yes
- **Secret Name**: test-secret
- **Access Verified**: ✅ Yes
```

## 📸 Screenshots to Capture

Take screenshots of the following and save them in `deliverables/screenshots/task1/`:

1. **Resource Group Overview**: Show the Foundry-RG resource group with Key Vault listed
2. **Key Vault Overview**: Show the Key Vault main page with URI and location
3. **Private Endpoint**: Show the private endpoint configuration
4. **Network Settings**: Show the firewall and virtual network settings
5. **Test Secret**: Show the successfully created test secret

## ✅ Validation Checklist

Before proceeding to Task 2, ensure:

- [ ] Resource group "Foundry-RG" is created and visible in Azure Portal
- [ ] Key Vault is created with the correct naming convention
- [ ] Private endpoint is configured and connected
- [ ] Your IP address is added to the firewall allow list
- [ ] You can successfully create and view secrets in the Key Vault
- [ ] Documentation is complete with all required details
- [ ] Screenshots are captured and organized

## 🚨 Troubleshooting

### Common Issues and Solutions:

**Issue**: Key Vault name already exists
- **Solution**: Key Vault names must be globally unique. Try adding numbers or your initials: `foundry-kv-john123`

**Issue**: Private endpoint creation fails
- **Solution**: Ensure you have sufficient permissions and the region supports private endpoints

**Issue**: Cannot access Key Vault after creation
- **Solution**: 
  1. Check if your IP is in the firewall allow list
  2. Verify access policies are correctly configured
  3. Wait 5-10 minutes for DNS propagation

**Issue**: "Access denied" when creating secrets
- **Solution**: Verify your user account has the correct access policy permissions

## 📚 Additional Resources

- [Azure Key Vault Overview](https://docs.microsoft.com/azure/key-vault/general/overview)
- [Private Endpoints for Key Vault](https://docs.microsoft.com/azure/key-vault/general/private-link-service)
- [Key Vault Network Security](https://docs.microsoft.com/azure/key-vault/general/network-security)

## ➡️ Next Step

Once you've completed this task and validated everything works, proceed to [Task 2: Development Tools Installation](task2-development-tools.md).

---

**💡 Pro Tip**: Keep your Key Vault URI handy - you'll need it for subsequent tasks!