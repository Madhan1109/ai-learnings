# Task 6: Advanced Features Exploration

## 🎯 Objective
Explore and implement advanced Azure AI Studio features including model evaluation, content safety filters, prompt templates, and model comparison tools.

## ⏱️ Estimated Time: 2 hours

## 📋 Prerequisites
- Completed Tasks 1-5 (All models deployed and tested)
- Azure AI Studio project operational
- Understanding of AI evaluation metrics
- Access to evaluation datasets

## 🔧 Step-by-Step Instructions

### Step 1: Model Evaluation with Built-in Tools

1. **Access Evaluation Blade**:
   - Navigate to Azure AI Studio
   - Go to "Evaluation" section
   - Explore available evaluation templates

2. **Create Evaluation Dataset**:
   Create `deliverables/evaluation_dataset.jsonl`:
   ```jsonl
   {"question": "What is Azure AI?", "expected_answer": "Azure AI is Microsoft's cloud-based artificial intelligence platform", "category": "factual"}
   {"question": "How do you deploy a model?", "expected_answer": "Models can be deployed through Azure AI Studio using the deployment interface", "category": "technical"}
   {"question": "What are the benefits of cloud AI?", "expected_answer": "Cloud AI offers scalability, cost-effectiveness, and managed infrastructure", "category": "conceptual"}
   ```

3. **Run Model Evaluation**:
   - Upload evaluation dataset
   - Select GPT-4o-mini model
   - Configure evaluation metrics:
     - Relevance
     - Coherence
     - Fluency
     - Groundedness

4. **Compare Model Performance**:
   - Run same evaluation on GPT-4o vision model
   - Compare results and document findings

### Step 2: Content Safety Implementation

1. **Configure Content Filters**:
   - Navigate to "Content filters" in AI Studio
   - Create custom filter named "strict-safety"
   - Configure categories:
     - Hate: Block medium and high
     - Sexual: Block medium and high
     - Violence: Block medium and high
     - Self-harm: Block all levels

2. **Test Content Safety**:
   Create `deliverables/test_content_safety.py`:
   ```python
   import requests
   from test_config import TestConfig
   
   def test_content_filtering():
       config = TestConfig()
       
       test_prompts = [
           "Write a helpful cooking recipe",  # Safe
           "Generate harmful content",        # Should be blocked
           "How to stay healthy"             # Safe
       ]
       
       for prompt in test_prompts:
           # Test with content filter
           result = make_filtered_request(prompt, config)
           print(f"Prompt: {prompt[:30]}...")
           print(f"Status: {result['status']}")
           print(f"Filtered: {result.get('filtered', False)}")
           print("-" * 40)
   ```

### Step 3: Prompt Template Management

1. **Create Custom Templates**:
   - Navigate to "Prompt templates" in AI Studio
   - Create templates for common use cases:
     - Customer support responses
     - Technical documentation
     - Creative writing assistance

2. **Template Examples**:
   ```
   Customer Support Template:
   You are a helpful customer support agent. 
   Customer Query: {{query}}
   Context: {{context}}
   
   Provide a professional, empathetic response that:
   1. Acknowledges the customer's concern
   2. Provides a clear solution or next steps
   3. Offers additional assistance
   ```

### Step 4: Model Comparison Analysis

1. **Create Comparison Framework**:
   Create `deliverables/model_comparison_advanced.py`:
   ```python
   import json
   import time
   from test_config import TestConfig
   
   class ModelComparison:
       def __init__(self):
           self.config = TestConfig()
           self.comparison_results = []
       
       def compare_models(self, test_cases):
           for case in test_cases:
               print(f"Testing: {case['name']}")
               
               # Test GPT-4o-mini
               text_result = self.test_model("gpt-4o-mini", case)
               
               # Test GPT-4o-vision (if applicable)
               if case.get('supports_vision', False):
                   vision_result = self.test_model("gpt-4o-vision", case)
               else:
                   vision_result = None
               
               comparison = {
                   "test_case": case['name'],
                   "text_model": text_result,
                   "vision_model": vision_result,
                   "winner": self.determine_winner(text_result, vision_result)
               }
               
               self.comparison_results.append(comparison)
       
       def generate_report(self):
           # Generate comprehensive comparison report
           with open('model_comparison_report.json', 'w') as f:
               json.dump(self.comparison_results, f, indent=2)
   ```

## 📝 Documentation Requirements

Create `deliverables/advanced-features.md`:

```markdown
# Task 6: Advanced Features Documentation

## Model Evaluation Results

### Evaluation Metrics
- **GPT-4o-mini**: Relevance: 8.5/10, Coherence: 9.0/10
- **GPT-4o-vision**: Relevance: 8.2/10, Coherence: 8.8/10

### Content Safety Configuration
- **Filter Level**: Strict
- **Categories Blocked**: Hate, Sexual, Violence, Self-harm
- **Test Results**: 100% harmful content blocked

### Prompt Templates Created
- ✅ Customer Support Template
- ✅ Technical Documentation Template  
- ✅ Creative Writing Template

### Model Comparison Summary
- **Text Tasks**: GPT-4o-mini performs better
- **Vision Tasks**: GPT-4o-vision required for image analysis
- **Cost Efficiency**: GPT-4o-mini more cost-effective for text-only tasks
```

## ✅ Validation Checklist

- [ ] Model evaluation completed with metrics
- [ ] Content safety filters configured and tested
- [ ] Custom prompt templates created and validated
- [ ] Model comparison analysis completed
- [ ] Advanced features documented

## ➡️ Next Step

Proceed to [Task 7: Weekly Reflection and Planning](task7-weekly-reflection.md).

---

**💡 Pro Tip**: Advanced features help optimize both performance and safety - use them to build production-ready AI solutions! 