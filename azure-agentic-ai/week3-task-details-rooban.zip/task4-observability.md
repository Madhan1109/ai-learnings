# Task 4: Observability Implementation

## 🎯 Objective
Explore and configure monitoring using Application Insights and Azure OpenAI metrics, then set up practical alerts based on real available metrics in the Azure portal.

## ⏱️ Estimated Time: 2 hours

## 📋 Prerequisites
- Completed Tasks 1-3 (Models deployed and prompt flow operational)
- Application Insights resource created during hub setup
- Azure OpenAI services deployed from Week 1
- Access to Azure Portal and Azure Monitor

## 🔧 Step-by-Step Instructions

### Step 1: Explore Application Insights Metrics

1. **Access Application Insights**:
   - Navigate to Azure Portal > Application Insights > your-app-insights-resource
   - From your AI Studio hub, you can also click on the Application Insights resource name
   - Note the Connection String from "Essentials" section

2. **Explore Available Metrics**:
   - Go to "Monitoring" > "Metrics"
   - Click "Select a metric" to see all available metrics:
     - **Server requests**: Request count and response times
     - **Failed requests**: Error count and failure rate
     - **Server response time**: Average response duration
     - **Availability**: Uptime percentage
     - **Dependencies**: External service calls (including OpenAI)
     - **Exceptions**: Application errors and crashes

3. **Create Your First Metric Chart**:
   - Select "Server requests" metric
   - Set aggregation to "Count"
   - Set time range to "Last 24 hours"
   - Click "Apply" to see the chart
   - Pin this chart to a dashboard for later use

### Step 2: Explore Azure OpenAI Metrics

1. **Access Azure OpenAI Metrics**:
   - Navigate to Azure Portal > Cognitive Services > your-openai-resource (from Week 1)
   - Go to "Monitoring" > "Metrics"
   - Explore available Azure OpenAI specific metrics:
     - **Total Calls**: Number of API calls made
     - **Total Tokens**: Token consumption across all models
     - **Total Errors**: Failed API calls
     - **Data In/Out**: Request and response data volume
     - **Latency**: Response time for OpenAI calls

2. **Create OpenAI Usage Charts**:
   - **Token Usage Chart**:
     - Metric: "Total Tokens"
     - Aggregation: "Sum"
     - Split by: "Model Name" (to see usage per model)
   - **API Calls Chart**:
     - Metric: "Total Calls"
     - Aggregation: "Count"
     - Time range: "Last 7 days"
   - **Error Rate Chart**:
     - Metric: "Total Errors"
     - Aggregation: "Count"
     - Split by: "Status Code"

3. **Test and Generate Data**:
   - Go back to Azure AI Studio
   - Run your multimodal prompt flow several times with different inputs
   - Return to metrics after 10-15 minutes to see the data populate

### Step 3: Advanced Metrics Analysis with KQL

1. **Application Insights Log Queries**:
   - Go to Application Insights > "Logs"
   - **Dependencies Query** (to see OpenAI calls):
   ```kusto
   dependencies
   | where timestamp > ago(24h)
   | where target contains "openai"
   | summarize avg(duration), count() by bin(timestamp, 1h), name
   | render timechart
   ```

   - **Request Performance Query**:
   ```kusto
   requests
   | where timestamp > ago(24h)
   | summarize 
       avg_duration = avg(duration),
       p95_duration = percentile(duration, 95),
       request_count = count()
   by bin(timestamp, 1h)
   | render timechart
   ```

2. **OpenAI Specific Queries**:
   - **Token Usage by Model**:
   ```kusto
   dependencies
   | where target contains "openai"
   | extend model = extract(@"deployments/([^/]+)", 1, url)
   | summarize total_calls = count() by model, bin(timestamp, 1d)
   | render columnchart
   ```

3. **Save and Pin Queries**:
   - Save each query with descriptive names
   - Pin the charts to your dashboard
   - Set up automatic refresh intervals

### Step 4: Set Up Comprehensive Alerts

1. **Application Insights Alerts**:
   - Navigate to Application Insights > "Monitoring" > "Alerts"
   - Click "Create" > "Alert rule"
   
   **High Response Time Alert**:
   - **Resource**: Your Application Insights resource
   - **Condition**: 
     - Signal: "Server response time"
     - Operator: "Greater than"
     - Threshold: 5000 ms (5 seconds)
     - Evaluation frequency: 5 minutes
     - Period: 15 minutes

   **Failed Request Alert**:
   - **Condition**:
     - Signal: "Failed requests"
     - Operator: "Greater than"
     - Threshold: 5 failures
     - Period: 15 minutes

2. **Azure OpenAI Alerts**:
   - Navigate to your Azure OpenAI resource > "Monitoring" > "Alerts"
   
   **High Token Usage Alert**:
   - **Condition**:
     - Signal: "Total Tokens"
     - Operator: "Greater than"
     - Threshold: 10000 tokens
     - Period: 1 hour
   
   **API Error Rate Alert**:
   - **Condition**:
     - Signal: "Total Errors"
     - Operator: "Greater than"
     - Threshold: 10 errors
     - Period: 15 minutes

3. **Configure Action Groups**:
   - Create Action Group named "AI-Monitoring-Alerts"
   - Add your email address for notifications
   - Add webhook for Teams/Slack (optional)
   - Test the action group to verify notifications work

### Step 5: Create Comprehensive Monitoring Dashboard

1. **Create New Dashboard**:
   - Go to Azure Portal > Dashboard
   - Click "New dashboard"
   - Name it "AI Services Monitoring Dashboard"

2. **Add Application Insights Tiles**:
   - Click "Add tile" > "Metrics"
   - Add these Application Insights metrics:
     - **Server Requests**: Count over last 24 hours
     - **Server Response Time**: Average over last 24 hours
     - **Failed Requests**: Count over last 24 hours
     - **Dependencies**: Response time for OpenAI calls

3. **Add Azure OpenAI Tiles**:
   - Add tiles for your OpenAI resource:
     - **Total Tokens**: Sum over last 7 days (split by model)
     - **Total Calls**: Count over last 24 hours
     - **Total Errors**: Count over last 24 hours
     - **Latency**: Average response time

4. **Add Custom Query Tiles**:
   - Pin your saved KQL queries from Step 3
   - Arrange tiles in logical sections:
     - **Performance Section**: Response times, latency
     - **Usage Section**: Token consumption, API calls
     - **Health Section**: Error rates, availability

5. **Configure Dashboard Settings**:
   - Set auto-refresh to 15 minutes
   - Configure time ranges for each tile
   - Share dashboard with team members if needed

### Step 6: Basic Health Check Script

1. **Create Simple Health Check**:
   Create `deliverables/basic_health_check.py`:
   ```python
   import requests
   import json
   from datetime import datetime
   import os

   def check_prompt_flow_health():
       """Simple health check for your prompt flow"""
       
       # You'll need to get these from your AI Studio prompt flow
       # Go to your prompt flow > Deploy > Test endpoint
       endpoint_url = "YOUR_PROMPT_FLOW_ENDPOINT"  # Replace with actual endpoint
       api_key = "YOUR_API_KEY"  # Replace with actual key
       
       headers = {
           "Content-Type": "application/json",
           "Authorization": f"Bearer {api_key}"
       }
       
       # Simple test payload
       test_data = {
           "image_url": "https://images.unsplash.com/photo-1506905925346-21bda4d32df4",
           "analysis_type": "general",
           "detail_level": "basic"
       }
       
       try:
           print("🔍 Testing prompt flow health...")
           response = requests.post(
               endpoint_url,
               headers=headers,
               json=test_data,
               timeout=30
           )
           
           if response.status_code == 200:
               print("✅ Prompt flow is healthy")
               result = {
                   "status": "healthy",
                   "response_time": response.elapsed.total_seconds(),
                   "timestamp": datetime.now().isoformat()
               }
           else:
               print(f"❌ Prompt flow returned {response.status_code}")
               result = {
                   "status": "error",
                   "status_code": response.status_code,
                   "timestamp": datetime.now().isoformat()
               }
               
       except Exception as e:
           print(f"❌ Health check failed: {str(e)}")
           result = {
               "status": "failed",
               "error": str(e),
               "timestamp": datetime.now().isoformat()
           }
       
       # Save results
       with open('health_check_results.json', 'w') as f:
           json.dump(result, f, indent=2)
       
       return result

   if __name__ == "__main__":
       print("🏥 Basic Health Check")
       print("Note: Update endpoint_url and api_key before running")
       check_prompt_flow_health()
   ```

## 📝 Documentation Requirements

Create `deliverables/observability-summary.md`:

```markdown
# Task 4: Observability Implementation Summary

## Metrics Explored and Configured

### Application Insights Metrics
- ✅ **Server Requests**: Request volume and patterns
- ✅ **Server Response Time**: Performance monitoring
- ✅ **Failed Requests**: Error tracking and rates
- ✅ **Dependencies**: External service calls (OpenAI)
- ✅ **Exceptions**: Application error monitoring

### Azure OpenAI Metrics
- ✅ **Total Calls**: API usage tracking
- ✅ **Total Tokens**: Token consumption by model
- ✅ **Total Errors**: OpenAI API error monitoring
- ✅ **Latency**: OpenAI response time tracking
- ✅ **Data In/Out**: Request/response volume

### Advanced KQL Queries Implemented
1. **OpenAI Dependencies Analysis**: Tracks calls to OpenAI endpoints
2. **Request Performance Analysis**: P95 response times and trends
3. **Token Usage by Model**: Consumption patterns across deployments

### Alert Rules Configured
1. **Application Insights Alerts**:
   - High Response Time (>5 seconds)
   - Failed Request Rate (>5 failures/15min)
2. **Azure OpenAI Alerts**:
   - High Token Usage (>10k tokens/hour)
   - API Error Rate (>10 errors/15min)
3. **Action Groups**: Email notifications with optional webhooks

### Comprehensive Dashboard Created
- **Performance Section**: Response times, latency metrics
- **Usage Section**: Token consumption, API call volumes
- **Health Section**: Error rates, availability monitoring
- **Auto-refresh**: 15-minute intervals for real-time insights

### Health Check System
- **Endpoint Monitoring**: Tests prompt flow availability
- **Response Time Tracking**: Monitors performance degradation
- **Error Detection**: Identifies service issues early

## Key Insights Discovered

### Application Insights Capabilities
- Automatic request/response tracking for AI Studio
- Rich dependency tracking for OpenAI calls
- Powerful KQL query language for custom analysis
- Easy integration with Azure Monitor alerts

### Azure OpenAI Monitoring
- Detailed token usage metrics by model
- API-level error tracking and categorization
- Latency monitoring for performance optimization
- Cost tracking through token consumption

### Best Practices Learned
- Set realistic alert thresholds based on baseline metrics
- Use multiple metric sources for comprehensive monitoring
- Implement both technical and business metric tracking
- Regular dashboard review and optimization

## Production Recommendations
- Implement custom business metrics for ROI tracking
- Set up automated cost alerts for budget management
- Create runbooks for common alert scenarios
- Establish SLA monitoring and reporting

## Screenshots Captured
- [ ] Application Insights metrics explorer
- [ ] Azure OpenAI metrics dashboard
- [ ] KQL query results and charts
- [ ] Alert rules configuration
- [ ] Comprehensive monitoring dashboard
- [ ] Health check script execution
```

## 📸 Screenshots to Capture

Save screenshots in `deliverables/screenshots/task4/`:

1. **Application Insights Metrics**: Metrics explorer showing server requests, response time, and dependencies
2. **Azure OpenAI Metrics**: Token usage, API calls, and error metrics
3. **KQL Query Results**: Charts from your custom queries showing OpenAI dependencies and performance
4. **Alert Rules Configuration**: Both Application Insights and OpenAI alert rules
5. **Comprehensive Dashboard**: Full monitoring dashboard with all sections
6. **Health Check Execution**: Script output showing endpoint testing results

## ✅ Validation Checklist

Before proceeding to Task 5, ensure:

- [ ] Application Insights metrics are visible and showing data
- [ ] Azure OpenAI metrics display token usage and API calls
- [ ] KQL queries return meaningful charts and data
- [ ] Alert rules are configured for both Application Insights and OpenAI
- [ ] Action groups are tested and notifications work
- [ ] Comprehensive dashboard shows all metric sections
- [ ] Health check script executes and reports status
- [ ] Documentation captures all metrics explored and configured

## 🚨 Troubleshooting

### Common Issues:

**No telemetry data visible**:
- Run your prompt flow a few times to generate data
- Wait 5-10 minutes for data to appear in Application Insights
- Check that you're looking at the correct time range

**Alerts not working**:
- Verify action group email address is correct
- Check alert rule conditions are realistic
- Test the action group manually

**Dashboard empty**:
- Ensure you've pinned queries that return data
- Check time range settings on dashboard tiles
- Verify Application Insights resource is correct

## ➡️ Next Step

Once you've completed basic monitoring setup, proceed to [Task 5: Basic Validation Testing](task5-automated-testing.md).

---

**💡 Pro Tip**: Start simple with monitoring - basic request/response tracking and error alerts will catch most issues. You can always add more sophisticated monitoring later!