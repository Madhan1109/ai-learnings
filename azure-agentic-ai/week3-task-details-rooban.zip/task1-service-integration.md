# Task 1: Service Integration

## 🎯 Objective
Connect your existing Cognitive Services from Week 1 to Azure AI Studio, creating a unified project workspace that integrates all your deployed services for seamless AI development.

## ⏱️ Estimated Time: 1.5 hours

## 📋 Prerequisites
- Completed Week 1 (All Cognitive Services deployed and tested)
- Azure CLI authenticated and working
- Access to Azure AI Studio (ai.azure.com)
- Key Vault with stored service credentials

## 🔧 Step-by-Step Instructions

### Step 1: Access Azure AI Studio

1. **Navigate to Azure AI Studio**:
   - Open your web browser and go to [https://ai.azure.com](https://ai.azure.com)
   - Sign in with your Azure account credentials
   - Verify you're in the correct subscription

2. **Explore the Updated Interface**:
   - Familiarize yourself with the main navigation
   - Note sections: Home, Build, Manage, Model catalog
   - Look for "Projects" or "Hubs" section

### Step 2: Create AI Studio Hub

1. **Create a New Hub**:
   - Click on "All hubs" or "Create hub"
   - Fill in the hub details:
     - **Hub name**: `foundry-hub-[yourname]`
     - **Subscription**: Your Azure subscription
     - **Resource group**: `Foundry-RG` (from Week 1)
     - **Location**: Same region as your Week 1 resources
     - **Connect Azure AI services**: Select existing
     - **Azure AI services**: Choose your deployed Cognitive Services

2. **Configure Hub Settings**:
   - **Storage account**: Create new or use existing
   - **Key vault**: Select your `foundry-kv-[yourname]` from Week 1
   - **Application insights**: Create new for monitoring
   - **Container registry**: Create new (for future use)

3. **Review and Create**:
   - Review all settings
   - Ensure all Week 1 services are connected
   - Click "Create" and wait for deployment

### Step 3: Create AI Studio Project

1. **Create New Project**:
   - Once hub is created, click "Create project"
   - Project details:
     - **Project name**: `multimodal-ai-project`
     - **Hub**: Select your newly created hub
     - **Description**: "Week 2 multimodal AI development project"

2. **Configure Project Settings**:
   - **Compute**: We'll configure this in later tasks
   - **Connections**: Verify all Cognitive Services are listed
   - **Data**: We'll add data sources in future weeks

### Step 4: Verify Service Connections

1. **Check Connected Services**:
   - Navigate to "Settings" > "Connections"
   - Verify you see:
     - Speech Service connection
     - Computer Vision connection
     - Document Intelligence connection
     - Key Vault connection

2. **Test Service Connectivity**:
   - For each service, click "Test connection"
   - Ensure all tests pass successfully
   - Note any connection issues for troubleshooting

### Step 5: Explore Model Catalog

1. **Access Model Catalog**:
   - Navigate to "Model catalog" in the left menu
   - Browse available models:
     - Azure OpenAI models (GPT-4, GPT-3.5, DALL-E)
     - Open source models (Llama, Mistral, etc.)
     - Specialized models for vision, speech, etc.

2. **Check Model Availability**:
   - Filter by "Azure OpenAI" models
   - Note which models are available in your region
   - Check quota and pricing information
   - Document available models for Task 2 planning

### Step 6: Configure Project Security

1. **Set Up Access Control**:
   - Navigate to "Settings" > "Access control"
   - Review your permissions (should be Owner/Contributor)
   - Note the managed identity created for the project

2. **Verify Key Vault Integration**:
   - Check that secrets from Week 1 are accessible
   - Test retrieving a service key through the interface
   - Ensure proper access policies are in place

### Step 7: Initial Project Setup

1. **Create Project Structure**:
   - Navigate to "Data" section
   - Create folders for organizing your work:
     - `week2-experiments`
     - `prompt-flows`
     - `model-deployments`
     - `test-data`

2. **Configure Default Settings**:
   - Set default compute target (we'll create this in Task 2)
   - Configure default data store
   - Set up experiment tracking preferences

## 📝 Documentation Requirements

Create a file `deliverables/service-integration.md`:

```markdown
# Task 1: Service Integration Documentation

## Azure AI Studio Hub Configuration
- **Hub Name**: foundry-hub-[yourname]
- **Resource Group**: Foundry-RG
- **Location**: [Your region]
- **Creation Date**: [Date created]
- **Status**: ✅ Successfully created

## Connected Services

### Cognitive Services Integration
- **Speech Service**: ✅ Connected and tested
  - Connection name: [Connection name]
  - Endpoint: [Service endpoint]
  - Status: Active
  
- **Computer Vision**: ✅ Connected and tested
  - Connection name: [Connection name]
  - Endpoint: [Service endpoint]
  - Status: Active
  
- **Document Intelligence**: ✅ Connected and tested
  - Connection name: [Connection name]
  - Endpoint: [Service endpoint]
  - Status: Active

### Supporting Services
- **Key Vault**: ✅ Connected
  - Vault name: foundry-kv-[yourname]
  - Access status: Verified
  
- **Storage Account**: ✅ Connected
  - Account name: [Storage account name]
  - Purpose: Project data and artifacts
  
- **Application Insights**: ✅ Connected
  - Resource name: [App Insights name]
  - Purpose: Monitoring and telemetry

## AI Studio Project Details
- **Project Name**: multimodal-ai-project
- **Hub**: foundry-hub-[yourname]
- **Creation Date**: [Date created]
- **Project ID**: [Project identifier]

## Model Catalog Assessment

### Available Azure OpenAI Models
- **GPT-4 Models**: [List available variants]
- **GPT-3.5 Models**: [List available variants]
- **DALL-E Models**: [List available variants]
- **Embedding Models**: [List available variants]

### Regional Availability
- **Current Region**: [Your region]
- **Model Limitations**: [Any regional restrictions noted]
- **Quota Status**: [Available quota for each model type]

## Security Configuration
- **Access Control**: ✅ Properly configured
- **Managed Identity**: ✅ Created and active
- **Key Vault Access**: ✅ Verified
- **Network Security**: [Any network restrictions applied]

## Project Structure Created
- ✅ week2-experiments folder
- ✅ prompt-flows folder
- ✅ model-deployments folder
- ✅ test-data folder

## Connection Test Results
- **Speech Service Test**: ✅ Pass
- **Vision Service Test**: ✅ Pass
- **Document Intelligence Test**: ✅ Pass
- **Key Vault Access Test**: ✅ Pass
- **Overall Integration Status**: ✅ All systems operational

## Next Steps Preparation
- ✅ Hub and project ready for model deployment
- ✅ All Week 1 services integrated successfully
- ✅ Model catalog reviewed and deployment targets identified
- ✅ Security and access controls verified
```

## 📸 Screenshots to Capture

Save screenshots in `deliverables/screenshots/task1/`:

1. **Azure AI Studio Dashboard**: Main interface showing your hub
2. **Hub Configuration**: Hub settings and connected services
3. **Project Overview**: Your multimodal-ai-project dashboard
4. **Service Connections**: All connected Cognitive Services
5. **Model Catalog**: Available models in your region
6. **Connection Tests**: Successful test results for all services
7. **Project Structure**: Created folders and organization
8. **Security Settings**: Access control and permissions

## ✅ Validation Checklist

Before proceeding to Task 2, ensure:

- [ ] Azure AI Studio hub is created and operational
- [ ] All Week 1 Cognitive Services are connected and tested
- [ ] AI Studio project is created with proper configuration
- [ ] Model catalog is accessible and models are available
- [ ] Key Vault integration is working correctly
- [ ] Project folder structure is organized
- [ ] All service connection tests pass
- [ ] Security and access controls are properly configured
- [ ] Documentation is complete with all service details
- [ ] Screenshots are captured and organized

## 🚨 Troubleshooting

### Common Issues and Solutions:

**Issue**: Cannot create AI Studio hub
- **Solution**: 
  1. Verify you have Contributor/Owner permissions on the subscription
  2. Check if AI Studio is available in your region
  3. Ensure resource group exists and is accessible

**Issue**: Cognitive Services not appearing in connections
- **Solution**: 
  1. Verify services are deployed and running from Week 1
  2. Check that services are in the same region as the hub
  3. Ensure proper permissions on the Cognitive Services resources

**Issue**: Connection tests failing
- **Solution**: 
  1. Verify service keys are correct in Key Vault
  2. Check network connectivity and firewall rules
  3. Ensure services are not paused or stopped

**Issue**: Model catalog shows no models
- **Solution**: 
  1. Check if your region supports Azure OpenAI
  2. Verify subscription has access to Azure OpenAI
  3. Try refreshing the page or switching regions

**Issue**: Key Vault access denied
- **Solution**: 
  1. Verify Key Vault access policies include AI Studio managed identity
  2. Check if Key Vault firewall allows AI Studio access
  3. Ensure proper RBAC roles are assigned

## 📚 Additional Resources

- [Azure AI Studio Documentation](https://learn.microsoft.com/azure/ai-studio/)
- [Azure AI Studio Hub Management](https://learn.microsoft.com/azure/ai-studio/how-to/create-azure-ai-resource)
- [Connecting Services to AI Studio](https://learn.microsoft.com/azure/ai-studio/how-to/connections-add)
- [Azure OpenAI in AI Studio](https://learn.microsoft.com/azure/ai-studio/how-to/deploy-models-openai)

## ➡️ Next Step

Once all services are integrated and tested successfully, proceed to [Task 2: Model Endpoint Deployment](task2-model-endpoints.md).

---

**💡 Pro Tip**: A well-integrated foundation makes all subsequent AI development much smoother - take time to verify everything works! 