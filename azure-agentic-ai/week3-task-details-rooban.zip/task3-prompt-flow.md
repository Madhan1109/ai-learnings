# Task 3: Multi-Step Prompt Flow

## 🎯 Objective
Build a sophisticated 4-step prompt flow that combines text and image processing capabilities, demonstrating advanced orchestration of multiple AI models in a cohesive workflow.

## ⏱️ Estimated Time: 2 hours

## 📋 Prerequisites
- Completed Task 2 (Model endpoints deployed and tested)
- Both GPT-4o-mini and GPT-4o vision models operational
- Azure AI Studio project with prompt flow capabilities
- Test images and sample data prepared

## 🔧 Step-by-Step Instructions

### Step 1: Design the Prompt Flow Architecture

1. **Define the Flow Concept**:
   - **Purpose**: Multimodal content analysis and report generation
   - **Input**: Image URL + Analysis requirements
   - **Output**: Comprehensive analysis report with recommendations

2. **Flow Steps Design**:
   - **Step 1**: Image Analysis (Vision Model)
   - **Step 2**: Content Extraction (Vision Model)
   - **Step 3**: Report Generation (Text Model)
   - **Step 4**: Output Formatting (Text Model)

3. **Data Flow Planning**:
   ```
   Input Image → Vision Analysis → Content Extraction → Report Generation → Formatted Output
   ```

### Step 2: Create the Prompt Flow in Azure AI Studio

1. **Navigate to Prompt Flow**:
   - In your AI Studio project, go to "Prompt flow"
   - Click "Create" or "New flow"
   - Choose "Chat flow" or "Standard flow"

2. **Configure Flow Basics**:
   - **Flow name**: `multimodal-analysis-flow`
   - **Description**: "4-step multimodal content analysis workflow"
   - **Runtime**: Select your compute instance

3. **Set Up Flow Inputs**:
   - **image_url** (string): URL of the image to analyze
   - **analysis_type** (string): Type of analysis required
   - **detail_level** (string): Level of detail (basic/detailed/comprehensive)

### Step 3: Implement Step 1 - Image Analysis

1. **Add Vision Analysis Node**:
   - Add a new node named "image_analysis"
   - Select "LLM" node type
   - Configure connection to your GPT-4o vision deployment

2. **Configure Vision Analysis Prompt**:
   ```
   You are an expert image analyst. Analyze the provided image and provide a comprehensive description.
   
   Image URL: ${inputs.image_url}
   Analysis Type: ${inputs.analysis_type}
   Detail Level: ${inputs.detail_level}
   
   Please provide:
   1. Overall scene description
   2. Key objects and elements identified
   3. Colors, composition, and visual style
   4. Any text or symbols visible
   5. Context and setting analysis
   
   Format your response as structured JSON:
   {
     "scene_description": "...",
     "key_objects": ["...", "..."],
     "visual_style": "...",
     "text_content": "...",
     "context": "..."
   }
   ```

3. **Configure Node Settings**:
   - **Connection**: Your GPT-4o vision deployment
   - **API**: chat
   - **Temperature**: 0.3
   - **Max tokens**: 500

### Step 4: Implement Step 2 - Content Extraction

1. **Add Content Extraction Node**:
   - Add node named "content_extraction"
   - Connect to GPT-4o vision deployment
   - Input: image_url + analysis from Step 1

2. **Configure Extraction Prompt**:
   ```
   Based on the initial analysis, extract specific content elements from the image.
   
   Previous Analysis: ${image_analysis.output}
   Image URL: ${inputs.image_url}
   
   Focus on extracting:
   1. Any readable text (OCR)
   2. Numerical data or measurements
   3. Brand names, logos, or identifiers
   4. Technical specifications if visible
   5. Actionable information
   
   Provide extraction results in JSON format:
   {
     "extracted_text": "...",
     "numerical_data": ["...", "..."],
     "identifiers": ["...", "..."],
     "technical_specs": "...",
     "actionable_items": ["...", "..."]
   }
   ```

3. **Node Configuration**:
   - **Temperature**: 0.1 (for accuracy)
   - **Max tokens**: 400

### Step 5: Implement Step 3 - Report Generation

1. **Add Report Generation Node**:
   - Add node named "report_generation"
   - Connect to GPT-4o-mini text deployment
   - Input: Combined analysis from Steps 1 & 2

2. **Configure Report Prompt**:
   ```
   Generate a comprehensive analysis report based on the image analysis and content extraction.
   
   Image Analysis: ${image_analysis.output}
   Content Extraction: ${content_extraction.output}
   Analysis Type: ${inputs.analysis_type}
   Detail Level: ${inputs.detail_level}
   
   Create a professional report that includes:
   
   ## Executive Summary
   Brief overview of the image and key findings
   
   ## Detailed Analysis
   Comprehensive breakdown of visual elements, content, and context
   
   ## Key Insights
   Important observations and patterns identified
   
   ## Recommendations
   Actionable suggestions based on the analysis
   
   ## Technical Details
   Any technical specifications or data extracted
   
   Write in a professional, analytical tone suitable for business or research purposes.
   ```

3. **Node Settings**:
   - **Temperature**: 0.5
   - **Max tokens**: 800

### Step 6: Implement Step 4 - Output Formatting

1. **Add Formatting Node**:
   - Add node named "output_formatting"
   - Connect to GPT-4o-mini deployment
   - Input: Report from Step 3

2. **Configure Formatting Prompt**:
   ```
   Format the analysis report for final presentation with proper structure and styling.
   
   Raw Report: ${report_generation.output}
   Detail Level: ${inputs.detail_level}
   
   Apply the following formatting:
   1. Add proper markdown formatting
   2. Include executive summary at the top
   3. Use bullet points and numbered lists where appropriate
   4. Add section dividers and headers
   5. Include a confidence score for the analysis
   6. Add timestamp and metadata
   
   Output should be ready for presentation or documentation.
   
   Include at the end:
   ---
   Analysis Confidence: [High/Medium/Low]
   Processing Date: [Current date]
   Models Used: GPT-4o Vision + GPT-4o-mini Text
   Flow Version: 1.0
   ```

3. **Final Node Configuration**:
   - **Temperature**: 0.2
   - **Max tokens**: 1000

### Step 7: Configure Flow Outputs

1. **Set Flow Outputs**:
   - **final_report**: ${output_formatting.output}
   - **analysis_summary**: ${image_analysis.output}
   - **extracted_content**: ${content_extraction.output}
   - **processing_metadata**: Timestamp and model info

2. **Add Error Handling**:
   - Configure fallback responses for each step
   - Add validation for image URL accessibility
   - Include timeout handling

### Step 8: Test the Complete Flow

1. **Prepare Test Cases**:
   
   **Test Case 1: Business Document**
   - Image: Screenshot of a business presentation slide
   - Analysis Type: "business_document"
   - Detail Level: "comprehensive"
   
   **Test Case 2: Technical Diagram**
   - Image: Technical architecture diagram
   - Analysis Type: "technical_analysis"
   - Detail Level: "detailed"
   
   **Test Case 3: Marketing Material**
   - Image: Advertisement or marketing poster
   - Analysis Type: "marketing_content"
   - Detail Level: "basic"

2. **Run Test Cases**:
   - Execute each test case through the flow
   - Monitor execution time for each step
   - Verify output quality and completeness
   - Check for any errors or failures

3. **Document Test Results**:
   Create `deliverables/flow_test_results.json`:
   ```json
   {
     "test_execution_date": "2024-01-15",
     "flow_version": "1.0",
     "test_cases": [
       {
         "test_name": "Business Document",
         "input": {
           "image_url": "...",
           "analysis_type": "business_document",
           "detail_level": "comprehensive"
         },
         "execution_time": "45.2s",
         "status": "success",
         "output_quality": "high",
         "step_timings": {
           "image_analysis": "12.3s",
           "content_extraction": "8.7s",
           "report_generation": "18.1s",
           "output_formatting": "6.1s"
         }
       }
     ]
   }
   ```

### Step 9: Export and Version the Flow

1. **Export Flow Definition**:
   - In AI Studio, go to flow settings
   - Export the flow as YAML or JSON
   - Save as `deliverables/prompt-flow-export.json`

2. **Create Flow Documentation**:
   ```yaml
   # multimodal-analysis-flow.yaml
   name: multimodal-analysis-flow
   version: "1.0"
   description: "4-step multimodal content analysis workflow"
   
   inputs:
     image_url:
       type: string
       description: "URL of the image to analyze"
     analysis_type:
       type: string
       description: "Type of analysis required"
     detail_level:
       type: string
       description: "Level of detail (basic/detailed/comprehensive)"
   
   nodes:
     image_analysis:
       type: llm
       source:
         type: code
         path: image_analysis.jinja2
       inputs:
         deployment_name: gpt-4o-vision
         temperature: 0.3
         max_tokens: 500
   
     content_extraction:
       type: llm
       source:
         type: code
         path: content_extraction.jinja2
       inputs:
         deployment_name: gpt-4o-vision
         temperature: 0.1
         max_tokens: 400
   
     report_generation:
       type: llm
       source:
         type: code
         path: report_generation.jinja2
       inputs:
         deployment_name: gpt-4o-mini-text
         temperature: 0.5
         max_tokens: 800
   
     output_formatting:
       type: llm
       source:
         type: code
         path: output_formatting.jinja2
       inputs:
         deployment_name: gpt-4o-mini-text
         temperature: 0.2
         max_tokens: 1000
   
   outputs:
     final_report:
       type: string
       reference: ${output_formatting.output}
   ```

## 📝 Documentation Requirements

Create a file `deliverables/prompt-flow-documentation.md`:

```markdown
# Task 3: Multi-Step Prompt Flow Documentation

## Flow Architecture

### Overview
- **Flow Name**: multimodal-analysis-flow
- **Version**: 1.0
- **Purpose**: Comprehensive multimodal content analysis
- **Steps**: 4 sequential processing steps
- **Models Used**: GPT-4o Vision + GPT-4o-mini Text

### Flow Design
```
Input → Image Analysis → Content Extraction → Report Generation → Output Formatting → Final Report
```

## Step Details

### Step 1: Image Analysis
- **Model**: GPT-4o Vision
- **Purpose**: Initial visual analysis and scene understanding
- **Temperature**: 0.3
- **Max Tokens**: 500
- **Output**: Structured JSON with scene description

### Step 2: Content Extraction
- **Model**: GPT-4o Vision
- **Purpose**: Extract specific content elements (text, data, identifiers)
- **Temperature**: 0.1
- **Max Tokens**: 400
- **Output**: JSON with extracted content

### Step 3: Report Generation
- **Model**: GPT-4o-mini Text
- **Purpose**: Generate comprehensive analysis report
- **Temperature**: 0.5
- **Max Tokens**: 800
- **Output**: Professional report structure

### Step 4: Output Formatting
- **Model**: GPT-4o-mini Text
- **Purpose**: Format report for presentation
- **Temperature**: 0.2
- **Max Tokens**: 1000
- **Output**: Markdown-formatted final report

## Test Results

### Performance Metrics
- **Average Execution Time**: [XX.X]s
- **Success Rate**: [XX]%
- **Step Breakdown**:
  - Image Analysis: [XX.X]s
  - Content Extraction: [XX.X]s
  - Report Generation: [XX.X]s
  - Output Formatting: [XX.X]s

### Test Cases Executed
1. **Business Document Analysis**: ✅ Success
2. **Technical Diagram Analysis**: ✅ Success
3. **Marketing Content Analysis**: ✅ Success

## Flow Capabilities
- ✅ Multimodal input processing
- ✅ Sequential step execution
- ✅ Error handling and validation
- ✅ Structured output generation
- ✅ Professional report formatting

## Use Cases
- Business document analysis
- Technical diagram interpretation
- Marketing content evaluation
- Educational material assessment
- Research image analysis

## Future Enhancements
- Add parallel processing capabilities
- Include additional output formats
- Implement batch processing
- Add custom model fine-tuning
```

## 📸 Screenshots to Capture

Save screenshots in `deliverables/screenshots/task3/`:

1. **Flow Designer**: Complete flow with all 4 steps
2. **Node Configuration**: Each step's prompt and settings
3. **Test Execution**: Flow running with sample inputs
4. **Output Results**: Final formatted reports
5. **Performance Metrics**: Execution times and success rates
6. **Flow Export**: Export interface and saved files
7. **Error Handling**: Any error scenarios encountered

## ✅ Validation Checklist

Before proceeding to Task 4, ensure:

- [ ] 4-step prompt flow is created and operational
- [ ] All nodes are properly connected and configured
- [ ] Vision model integration works correctly
- [ ] Text model integration works correctly
- [ ] Flow accepts inputs and produces outputs
- [ ] Test cases execute successfully
- [ ] Performance metrics are documented
- [ ] Flow is exported and versioned
- [ ] Error handling is implemented
- [ ] Documentation is complete with examples

## 🚨 Troubleshooting

### Common Issues and Solutions:

**Issue**: Flow execution fails at vision steps
- **Solution**: 
  1. Verify image URLs are accessible
  2. Check vision model deployment status
  3. Validate image format and size

**Issue**: Inconsistent output quality
- **Solution**: 
  1. Adjust temperature settings for consistency
  2. Refine prompts with more specific instructions
  3. Add validation steps between nodes

**Issue**: Long execution times
- **Solution**: 
  1. Optimize prompt lengths
  2. Reduce max tokens where possible
  3. Consider parallel processing for independent steps

**Issue**: Flow connections not working
- **Solution**: 
  1. Check node input/output mappings
  2. Verify variable names match exactly
  3. Test each node individually

## 📚 Additional Resources

- [Azure AI Studio Prompt Flow](https://learn.microsoft.com/azure/ai-studio/how-to/prompt-flow)
- [Prompt Flow Best Practices](https://learn.microsoft.com/azure/ai-studio/how-to/prompt-flow-tools/overview)
- [Multimodal AI Patterns](https://learn.microsoft.com/azure/cognitive-services/openai/concepts/use-cases)

## ➡️ Next Step

Once your prompt flow is working correctly and tested, proceed to [Task 4: Observability Implementation](task4-observability.md).

---

**💡 Pro Tip**: Start simple and add complexity gradually - test each step individually before connecting the full flow! 