# Task 5: Basic Validation Testing 🧪

**Estimated Time:** 1.5 hours  
**Difficulty:** Intermediate  
**Prerequisites:** Week 2 Tasks 1-4 completed (models deployed and monitored)

## 🎯 Objective
Create simple validation tests for your deployed AI models and prompt flows to ensure they're working correctly and meeting basic performance expectations.

## 📚 What You'll Learn
- Write basic tests for AI model endpoints
- Validate model responses and performance
- Create simple test automation with Python
- Understand basic testing principles for AI systems
- Document test results and findings

## 🔧 Prerequisites
- Completed Tasks 1-4 (models deployed, flows created, monitoring active)
- Python environment with basic testing libraries
- Access to deployed model endpoints
- Understanding of API testing concepts

## 📋 Step-by-Step Instructions

### Step 1: Set Up Basic Testing Environment (20 minutes)

#### 1.1 Install Testing Dependencies
Create `deliverables/requirements-testing.txt`:
```txt
pytest==7.4.3
requests==2.31.0
azure-keyvault-secrets==4.7.0
azure-identity==1.15.0
```

#### 1.2 Install Dependencies
```bash
cd docs/week2/deliverables
pip install -r requirements-testing.txt
```

#### 1.3 Create Test Configuration
Create `deliverables/test_config.py`:
```python
import os
from azure.keyvault.secrets import SecretClient
from azure.identity import DefaultAzureCredential

class TestConfig:
    def __init__(self):
        # Initialize Key Vault client
        credential = DefaultAzureCredential()
        self.secret_client = SecretClient(
            vault_url="https://foundry-kv-rooban.vault.azure.net/",
            credential=credential
        )
        
        # Load configuration
        self.endpoints = self._load_endpoints()
    
    def _load_endpoints(self):
        """Load endpoint configurations from Key Vault"""
        return {
            "gpt-4o-mini": {
                "endpoint": self.secret_client.get_secret("gpt-4o-mini-endpoint").value,
                "key": self.secret_client.get_secret("gpt-4o-mini-key").value,
                "deployment": "gpt-4o-mini-text"
            },
            "gpt-4o-vision": {
                "endpoint": self.secret_client.get_secret("gpt-4o-vision-endpoint").value,
                "key": self.secret_client.get_secret("gpt-4o-vision-key").value,
                "deployment": "gpt-4o-vision"
            }
        }
```

#### 1.4 Validation Checklist
- [ ] Testing dependencies installed
- [ ] Test configuration created
- [ ] Key Vault access verified
- [ ] Python environment ready

### Step 2: Create Basic Model Tests (30 minutes)

#### 2.1 Create Base Test Helper
Create `deliverables/test_helpers.py`:
```python
import requests
import time
import json
from test_config import TestConfig

class ModelTester:
    def __init__(self):
        self.config = TestConfig()
        self.test_results = []
    
    def test_model_endpoint(self, model_name, messages, max_tokens=100, temperature=0.3):
        """Test a model endpoint with given messages"""
        endpoint_config = self.config.endpoints[model_name]
        
        headers = {
            "Content-Type": "application/json",
            "api-key": endpoint_config["key"]
        }
        
        payload = {
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature
        }
        
        url = f"{endpoint_config['endpoint']}/openai/deployments/{endpoint_config['deployment']}/chat/completions?api-version=2024-02-15-preview"
        
        start_time = time.time()
        
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=30)
            end_time = time.time()
            
            result = {
                "model": model_name,
                "status_code": response.status_code,
                "response_time": end_time - start_time,
                "success": response.status_code == 200,
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            
            if response.status_code == 200:
                response_data = response.json()
                result.update({
                    "content": response_data.get("choices", [{}])[0].get("message", {}).get("content", ""),
                    "tokens_used": response_data.get("usage", {}).get("total_tokens", 0),
                    "finish_reason": response_data.get("choices", [{}])[0].get("finish_reason", "")
                })
            else:
                result["error"] = response.text
            
            self.test_results.append(result)
            return result
            
        except Exception as e:
            end_time = time.time()
            result = {
                "model": model_name,
                "status_code": 0,
                "response_time": end_time - start_time,
                "success": False,
                "error": str(e),
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            self.test_results.append(result)
            return result
    
    def save_results(self, filename="test_results.json"):
        """Save test results to file"""
        with open(filename, 'w') as f:
            json.dump(self.test_results, f, indent=2)
```

#### 2.2 Create Text Model Tests
Create `deliverables/test_text_model.py`:
```python
import pytest
from test_helpers import ModelTester

class TestTextModel:
    def setup_method(self):
        self.tester = ModelTester()
    
    def test_basic_question_answering(self):
        """Test basic Q&A functionality"""
        messages = [{"role": "user", "content": "What is Azure AI Foundry?"}]
        result = self.tester.test_model_endpoint("gpt-4o-mini", messages)
        
        assert result["success"], f"API call failed: {result.get('error', 'Unknown error')}"
        assert result["response_time"] <= 10.0, f"Response time {result['response_time']:.2f}s too high"
        assert len(result["content"]) >= 20, "Response too short"
        assert "azure" in result["content"].lower(), "Response should mention Azure"
    
    def test_simple_math(self):
        """Test basic mathematical reasoning"""
        messages = [{"role": "user", "content": "What is 15 + 27?"}]
        result = self.tester.test_model_endpoint("gpt-4o-mini", messages, temperature=0.1)
        
        assert result["success"], "Math question should succeed"
        assert "42" in result["content"], "Should correctly calculate 15 + 27 = 42"
        assert result["tokens_used"] <= 50, "Simple math should use few tokens"
    
    def test_code_generation(self):
        """Test simple code generation"""
        messages = [{"role": "user", "content": "Write a Python function to add two numbers"}]
        result = self.tester.test_model_endpoint("gpt-4o-mini", messages, max_tokens=150)
        
        assert result["success"], "Code generation should succeed"
        content_lower = result["content"].lower()
        assert "def" in content_lower, "Should contain function definition"
        assert "return" in content_lower, "Should contain return statement"
    
    def test_response_consistency(self):
        """Test response consistency for factual questions"""
        messages = [{"role": "user", "content": "What is the capital of France?"}]
        
        responses = []
        for i in range(3):
            result = self.tester.test_model_endpoint("gpt-4o-mini", messages, temperature=0.0)
            assert result["success"], f"Call {i+1} failed"
            responses.append(result["content"].lower())
        
        # All responses should mention Paris
        assert all("paris" in response for response in responses), "All responses should mention Paris"
```

#### 2.3 Create Vision Model Tests
Create `deliverables/test_vision_model.py`:
```python
import pytest
from test_helpers import ModelTester

class TestVisionModel:
    def setup_method(self):
        self.tester = ModelTester()
    
    def test_image_description(self):
        """Test basic image description"""
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Describe this image briefly"},
                    {"type": "image_url", "image_url": {"url": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Gfp-wisconsin-madison-the-nature-boardwalk.jpg/2560px-Gfp-wisconsin-madison-the-nature-boardwalk.jpg"}}
                ]
            }
        ]
        
        result = self.tester.test_model_endpoint("gpt-4o-vision", messages, max_tokens=200)
        
        assert result["success"], f"Vision API call failed: {result.get('error', 'Unknown error')}"
        assert result["response_time"] <= 15.0, f"Vision response time {result['response_time']:.2f}s too high"
        assert len(result["content"]) >= 30, "Vision description too short"
        
        # Check for visual description content
        content_lower = result["content"].lower()
        visual_keywords = ["image", "see", "shows", "appears", "visible", "scene", "picture"]
        assert any(keyword in content_lower for keyword in visual_keywords), "Should contain visual description"
    
    def test_text_in_image(self):
        """Test OCR capability"""
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "What text do you see in this image?"},
                    {"type": "image_url", "image_url": {"url": "https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Microsoft_logo_%282012%29.svg/2560px-Microsoft_logo_%282012%29.svg.png"}}
                ]
            }
        ]
        
        result = self.tester.test_model_endpoint("gpt-4o-vision", messages, max_tokens=100)
        
        assert result["success"], "OCR test should succeed"
        content_lower = result["content"].lower()
        assert "microsoft" in content_lower, "Should recognize Microsoft text in logo"
```

#### 2.4 Validation Checklist
- [ ] Base test helper created
- [ ] Text model tests implemented
- [ ] Vision model tests implemented
- [ ] All tests use appropriate assertions

### Step 3: Create Simple Test Runner (15 minutes)

#### 3.1 Create Test Runner Script
Create `deliverables/run_tests.py`:
```python
import subprocess
import sys
import json
from datetime import datetime
from test_helpers import ModelTester

def run_basic_tests():
    """Run basic validation tests"""
    print("🧪 Running Basic AI Model Validation Tests")
    print("=" * 50)
    
    # Run pytest tests
    test_commands = [
        ("Text Model Tests", ["pytest", "test_text_model.py", "-v", "--tb=short"]),
        ("Vision Model Tests", ["pytest", "test_vision_model.py", "-v", "--tb=short"])
    ]
    
    results = []
    
    for test_name, command in test_commands:
        print(f"\n🔍 Running: {test_name}")
        print("-" * 30)
        
        try:
            result = subprocess.run(command, capture_output=True, text=True, timeout=300)
            
            if result.returncode == 0:
                print(f"✅ {test_name} - PASSED")
                results.append((test_name, True, ""))
            else:
                print(f"❌ {test_name} - FAILED")
                error_output = result.stderr if result.stderr else result.stdout
                print(f"Error details: {error_output[:300]}...")
                results.append((test_name, False, error_output))
                
        except subprocess.TimeoutExpired:
            print(f"⏰ {test_name} - TIMEOUT (5 minutes)")
            results.append((test_name, False, "Test timed out"))
        except Exception as e:
            print(f"❌ {test_name} - ERROR: {e}")
            results.append((test_name, False, str(e)))
    
    # Generate summary report
    generate_test_report(results)
    
    # Print final summary
    print("\n" + "=" * 50)
    print("📊 TEST SUMMARY")
    print("=" * 50)
    
    passed = len([r for r in results if r[1]])
    total = len(results)
    
    for test_name, success, error in results:
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{test_name}: {status}")
    
    print(f"\nOverall: {passed}/{total} tests passed")
    success_rate = (passed / total) * 100 if total > 0 else 0
    print(f"Success Rate: {success_rate:.1f}%")
    
    if passed == total:
        print("🎉 All basic validation tests passed!")
        return True
    else:
        print("⚠️ Some tests failed - check the detailed output above")
        return False

def generate_test_report(results):
    """Generate a simple test report"""
    report = {
        "test_run_date": datetime.now().isoformat(),
        "total_tests": len(results),
        "passed_tests": len([r for r in results if r[1]]),
        "failed_tests": len([r for r in results if not r[1]]),
        "success_rate": (len([r for r in results if r[1]]) / len(results) * 100) if results else 0,
        "test_results": [
            {
                "test_name": name,
                "status": "PASS" if success else "FAIL",
                "error": error if error else None
            }
            for name, success, error in results
        ]
    }
    
    with open("test_report.json", "w") as f:
        json.dump(report, f, indent=2)
    
    print(f"\n📄 Test report saved to: test_report.json")

if __name__ == "__main__":
    success = run_basic_tests()
    sys.exit(0 if success else 1)
```

#### 3.2 Validation Checklist
- [ ] Test runner script created
- [ ] Report generation implemented
- [ ] Error handling included
- [ ] Summary output formatted

### Step 4: Run Tests and Document Results (15 minutes)

#### 4.1 Execute Test Suite
```bash
cd docs/week2/deliverables
python run_tests.py
```

#### 4.2 Review Test Results
1. Check console output for test results
2. Review `test_report.json` for detailed results
3. Examine any test failures and their causes
4. Note performance metrics (response times)

#### 4.3 Create Test Documentation
Create `deliverables/testing-summary.md`:
```markdown
# Week 2 Task 5: Basic Validation Testing Summary

## Test Execution Results

### Test Run Information
- **Date**: [Date and time of test run]
- **Total Tests**: [X]
- **Passed**: [X]
- **Failed**: [X]
- **Success Rate**: [XX]%

### Test Categories

#### Text Model Tests (GPT-4o-mini)
- ✅/❌ Basic question answering
- ✅/❌ Simple mathematical reasoning
- ✅/❌ Code generation capability
- ✅/❌ Response consistency

#### Vision Model Tests (GPT-4o-vision)
- ✅/❌ Image description
- ✅/❌ Text recognition (OCR)

### Performance Observations

#### Response Times
- **Text Model Average**: [X.X] seconds
- **Vision Model Average**: [X.X] seconds
- **Performance Rating**: Good/Acceptable/Needs Improvement

#### Token Usage
- **Average Tokens per Request**: [XX]
- **Token Efficiency**: Good/Acceptable/High

### Issues Encountered

#### Test Failures (if any)
1. **[Test Name]**
   - Error: [Description]
   - Cause: [Root cause]
   - Resolution: [How fixed or workaround]

#### Performance Issues (if any)
1. **[Issue Description]**
   - Impact: [How it affected tests]
   - Resolution: [Steps taken]

### Key Learnings

#### About Model Behavior
- [What you learned about how the models respond]
- [Any surprising behaviors or limitations discovered]

#### About Testing AI Systems
- [Insights about testing AI models]
- [Challenges specific to AI testing]

### Recommendations

#### For Model Usage
- [Recommendations based on test results]
- [Best practices discovered]

#### For Future Testing
- [Improvements for next testing cycle]
- [Additional tests that would be valuable]

### Next Steps
- [Actions to take based on test results]
- [Areas for improvement or investigation]

---

**Test Summary**: [Overall assessment of model performance and testing process]
```

#### 4.4 Validation Checklist
- [ ] Tests executed successfully
- [ ] Results documented in summary
- [ ] Performance metrics recorded
- [ ] Issues and learnings captured

### Step 5: Create Simple Monitoring Check (10 minutes)

#### 5.1 Create Health Check Script
Create `deliverables/health_check.py`:
```python
import time
from test_helpers import ModelTester

def quick_health_check():
    """Quick health check for deployed models"""
    print("🏥 Quick Health Check for AI Models")
    print("=" * 40)
    
    tester = ModelTester()
    
    # Simple health check tests
    health_tests = [
        {
            "name": "GPT-4o-mini Basic Response",
            "model": "gpt-4o-mini",
            "messages": [{"role": "user", "content": "Hello, are you working?"}],
            "expected_time": 5.0
        },
        {
            "name": "GPT-4o-vision Basic Response", 
            "model": "gpt-4o-vision",
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "Can you see images?"},
                        {"type": "image_url", "image_url": {"url": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Gfp-wisconsin-madison-the-nature-boardwalk.jpg/2560px-Gfp-wisconsin-madison-the-nature-boardwalk.jpg"}}
                    ]
                }
            ],
            "expected_time": 10.0
        }
    ]
    
    results = []
    
    for test in health_tests:
        print(f"\n🔍 Testing: {test['name']}")
        
        result = tester.test_model_endpoint(
            test["model"], 
            test["messages"], 
            max_tokens=50, 
            temperature=0.3
        )
        
        # Evaluate health
        is_healthy = (
            result["success"] and 
            result["response_time"] <= test["expected_time"] and
            len(result.get("content", "")) > 5
        )
        
        status = "✅ HEALTHY" if is_healthy else "❌ UNHEALTHY"
        print(f"   Status: {status}")
        print(f"   Response Time: {result['response_time']:.2f}s")
        print(f"   Content Length: {len(result.get('content', ''))} chars")
        
        results.append({
            "test_name": test["name"],
            "model": test["model"],
            "healthy": is_healthy,
            "response_time": result["response_time"],
            "success": result["success"]
        })
    
    # Overall health summary
    healthy_count = len([r for r in results if r["healthy"]])
    total_count = len(results)
    
    print(f"\n📊 Overall Health: {healthy_count}/{total_count} models healthy")
    
    if healthy_count == total_count:
        print("🎉 All models are healthy!")
    else:
        print("⚠️ Some models need attention")
    
    return results

if __name__ == "__main__":
    health_check_results = quick_health_check()
```

#### 5.2 Validation Checklist
- [ ] Health check script created
- [ ] Basic health tests implemented
- [ ] Health status reporting included
- [ ] Script can be run independently

## 📊 Deliverables

Save all deliverables in `docs/week2/deliverables/`:

### Required Files
1. **`requirements-testing.txt`** - Testing dependencies
2. **`test_config.py`** - Test configuration and Key Vault integration
3. **`test_helpers.py`** - Base testing utilities
4. **`test_text_model.py`** - Text model validation tests
5. **`test_vision_model.py`** - Vision model validation tests
6. **`run_tests.py`** - Test runner script
7. **`health_check.py`** - Simple health check script
8. **`testing-summary.md`** - Test results documentation
9. **`test_report.json`** - Generated test report (after running tests)

### Screenshots
1. `test-execution.png` - Console output from test runs
2. `test-results.png` - Test report summary
3. `health-check.png` - Health check output

## ✅ Success Criteria

- [ ] Basic validation tests created for both models
- [ ] Tests execute successfully with 90%+ pass rate
- [ ] Response times within acceptable limits (text <5s, vision <10s)
- [ ] Test documentation completed
- [ ] Health check script functional
- [ ] All deliverables properly organized

## 🚨 Troubleshooting

### Common Issues

**Tests Timing Out**
- Check network connectivity
- Verify model endpoints are active
- Increase timeout values if needed

**Authentication Errors**
- Verify Key Vault access
- Check API keys are current
- Ensure proper Azure credentials

**Test Failures**
- Review error messages carefully
- Check model deployment status
- Verify test expectations are realistic

**Performance Issues**
- Monitor Azure portal for service health
- Check for quota limits
- Consider regional latency

### Getting Help
- Review [Azure OpenAI Testing Best Practices](https://learn.microsoft.com/azure/ai-services/openai/how-to/monitoring)
- Check [pytest Documentation](https://docs.pytest.org/) for testing help
- Monitor Azure service health dashboard

## 🎓 Learning Questions

After completing this task, reflect on:

1. **Testing Strategy**: What makes testing AI models different from traditional software?
2. **Performance Expectations**: What response times are acceptable for different use cases?
3. **Reliability**: How consistent are your model responses across multiple runs?
4. **Error Handling**: What types of errors did you encounter and how did you handle them?
5. **Monitoring**: How would you monitor these models in a production environment?

## ➡️ Next Steps

Proceed to [Task 6: Advanced Features Exploration](task6-advanced-features.md) to explore additional Azure AI Studio capabilities.

---

**💡 Pro Tip**: Good testing is about finding the right balance between thoroughness and practicality. Start simple and add complexity as needed! 