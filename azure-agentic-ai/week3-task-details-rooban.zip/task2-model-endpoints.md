# Task 2: Model Endpoint Deployment

## 🎯 Objective
Deploy multiple Azure OpenAI model endpoints (text and vision models) in Azure AI Studio, configure them for optimal performance, and conduct comprehensive testing to compare capabilities and performance metrics.

## ⏱️ Estimated Time: 2 hours

## 📋 Prerequisites
- Completed Task 1 (Service Integration)
- Azure AI Studio hub and project operational
- Access to Azure OpenAI models in your region
- Model catalog reviewed and available models identified

## 🔧 Step-by-Step Instructions

### Step 1: Deploy GPT-4o-mini Text Model

1. **Navigate to Model Deployments**:
   - In your AI Studio project, go to "Deployments" section
   - Click "Create deployment" or "Deploy model"

2. **Select GPT-4o-mini Model**:
   - Browse the model catalog or search for "gpt-4o-mini"
   - Select the latest version available
   - Review model specifications and capabilities

3. **Configure Deployment Settings**:
   - **Deployment name**: `gpt-4o-mini-text`
   - **Deployment type**: Standard
   - **Model version**: Latest available
   - **Capacity**: Start with 10 TPM (Tokens Per Minute)
   - **Content filter**: Default (Moderate)

4. **Advanced Configuration**:
   - **Region**: Same as your hub
   - **Pricing tier**: Standard
   - **Auto-scaling**: Enabled
   - **Max capacity**: 50 TPM

5. **Deploy and Verify**:
   - Click "Deploy" and wait for completion
   - Verify deployment status shows "Succeeded"
   - Note the endpoint URL and deployment ID

### Step 2: Deploy GPT-4o Vision Model

1. **Create Second Deployment**:
   - Click "Create deployment" again
   - Search for "gpt-4o" (with vision capabilities)

2. **Configure Vision Model**:
   - **Deployment name**: `gpt-4o-vision`
   - **Model**: GPT-4o (latest version with vision)
   - **Deployment type**: Standard
   - **Capacity**: 10 TPM initially
   - **Content filter**: Default

3. **Vision-Specific Settings**:
   - **Image processing**: Enabled
   - **Max image size**: Default (20MB)
   - **Supported formats**: JPEG, PNG, GIF, BMP
   - **Max images per request**: 10

4. **Complete Deployment**:
   - Review all settings
   - Deploy and verify success
   - Test basic connectivity

### Step 3: Configure API Keys and Authentication

1. **Generate API Keys**:
   - For each deployment, navigate to "Keys and Endpoint"
   - Generate new API keys
   - Copy both Key 1 and Key 2 for redundancy

2. **Store Keys in Key Vault**:
   ```bash
   # Store GPT-4o-mini key
   az keyvault secret set \
     --vault-name "foundry-kv-yourname" \
     --name "gpt-4o-mini-key" \
     --value "your-api-key-here"
   
   # Store GPT-4o vision key
   az keyvault secret set \
     --vault-name "foundry-kv-yourname" \
     --name "gpt-4o-vision-key" \
     --value "your-api-key-here"
   
   # Store endpoints
   az keyvault secret set \
     --vault-name "foundry-kv-yourname" \
     --name "gpt-4o-mini-endpoint" \
     --value "your-endpoint-url"
   
   az keyvault secret set \
     --vault-name "foundry-kv-yourname" \
     --name "gpt-4o-vision-endpoint" \
     --value "your-endpoint-url"
   ```

### Step 4: Test Text Model Endpoint

1. **Create Test Script**:
   Create `deliverables/test_text_model.py`:
   ```python
   import requests
   import json
   import time
   from azure.keyvault.secrets import SecretClient
   from azure.identity import DefaultAzureCredential
   
   # Key Vault setup
   credential = DefaultAzureCredential()
   secret_client = SecretClient(vault_url="https://foundry-kv-yourname.vault.azure.net/", credential=credential)
   
   # Get credentials
   api_key = secret_client.get_secret("gpt-4o-mini-key").value
   endpoint = secret_client.get_secret("gpt-4o-mini-endpoint").value
   
   def test_text_model():
       """Test GPT-4o-mini with various text prompts"""
       
       test_cases = [
           {
               "name": "Simple Question",
               "prompt": "What is Azure AI Foundry and how does it help developers?",
               "max_tokens": 150
           },
           {
               "name": "Code Generation",
               "prompt": "Write a Python function to calculate the factorial of a number.",
               "max_tokens": 200
           },
           {
               "name": "Creative Writing",
               "prompt": "Write a short story about an AI learning to paint.",
               "max_tokens": 300
           }
       ]
       
       results = []
       
       for test in test_cases:
           print(f"\n🧪 Testing: {test['name']}")
           
           headers = {
               "Content-Type": "application/json",
               "api-key": api_key
           }
           
           data = {
               "messages": [
                   {"role": "user", "content": test["prompt"]}
               ],
               "max_tokens": test["max_tokens"],
               "temperature": 0.7
           }
           
           start_time = time.time()
           
           try:
               response = requests.post(
                   f"{endpoint}/openai/deployments/gpt-4o-mini-text/chat/completions?api-version=2024-02-15-preview",
                   headers=headers,
                   json=data
               )
               
               end_time = time.time()
               response_time = end_time - start_time
               
               if response.status_code == 200:
                   result = response.json()
                   content = result['choices'][0]['message']['content']
                   tokens_used = result['usage']['total_tokens']
                   
                   test_result = {
                       "test_name": test['name'],
                       "status": "✅ Success",
                       "response_time": f"{response_time:.2f}s",
                       "tokens_used": tokens_used,
                       "content_preview": content[:100] + "..." if len(content) > 100 else content
                   }
                   
                   print(f"   Status: ✅ Success")
                   print(f"   Response time: {response_time:.2f}s")
                   print(f"   Tokens used: {tokens_used}")
                   print(f"   Preview: {content[:100]}...")
                   
               else:
                   test_result = {
                       "test_name": test['name'],
                       "status": f"❌ Failed ({response.status_code})",
                       "error": response.text
                   }
                   print(f"   Status: ❌ Failed - {response.status_code}")
                   print(f"   Error: {response.text}")
               
               results.append(test_result)
               
           except Exception as e:
               print(f"   Status: ❌ Exception - {str(e)}")
               results.append({
                   "test_name": test['name'],
                   "status": f"❌ Exception",
                   "error": str(e)
               })
       
       return results
   
   if __name__ == "__main__":
       print("🚀 Testing GPT-4o-mini Text Model")
       results = test_text_model()
       
       # Save results
       with open('text_model_test_results.json', 'w') as f:
           json.dump(results, f, indent=2)
       
       print("\n📊 Test Summary:")
       for result in results:
           print(f"   {result['test_name']}: {result['status']}")
   ```

2. **Run Text Model Tests**:
   ```bash
   cd docs/week2/deliverables
   python test_text_model.py
   ```

### Step 5: Test Vision Model Endpoint

1. **Create Vision Test Script**:
   Create `deliverables/test_vision_model.py`:
   ```python
   import requests
   import json
   import time
   import base64
   from azure.keyvault.secrets import SecretClient
   from azure.identity import DefaultAzureCredential
   
   # Key Vault setup
   credential = DefaultAzureCredential()
   secret_client = SecretClient(vault_url="https://foundry-kv-yourname.vault.azure.net/", credential=credential)
   
   # Get credentials
   api_key = secret_client.get_secret("gpt-4o-vision-key").value
   endpoint = secret_client.get_secret("gpt-4o-vision-endpoint").value
   
   def encode_image_url(image_url):
       """Download and encode image from URL"""
       try:
           response = requests.get(image_url)
           if response.status_code == 200:
               return base64.b64encode(response.content).decode('utf-8')
       except Exception as e:
           print(f"Error downloading image: {e}")
       return None
   
   def test_vision_model():
       """Test GPT-4o vision with various image analysis tasks"""
       
       test_cases = [
           {
               "name": "Object Detection",
               "image_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Gfp-wisconsin-madison-the-nature-boardwalk.jpg/2560px-Gfp-wisconsin-madison-the-nature-boardwalk.jpg",
               "prompt": "What objects and elements do you see in this image? Describe the scene in detail."
           },
           {
               "name": "Text Recognition",
               "image_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/8/86/Microsoft_logo_%282012%29.svg/2560px-Microsoft_logo_%282012%29.svg.png",
               "prompt": "What text do you see in this image? Read any visible text."
           },
           {
               "name": "Scene Analysis",
               "image_url": "https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/Vd-Orig.png/256px-Vd-Orig.png",
               "prompt": "Analyze this image and describe what you see. What is the context or setting?"
           }
       ]
       
       results = []
       
       for test in test_cases:
           print(f"\n🧪 Testing: {test['name']}")
           
           headers = {
               "Content-Type": "application/json",
               "api-key": api_key
           }
           
           data = {
               "messages": [
                   {
                       "role": "user",
                       "content": [
                           {"type": "text", "text": test["prompt"]},
                           {"type": "image_url", "image_url": {"url": test["image_url"]}}
                       ]
                   }
               ],
               "max_tokens": 300,
               "temperature": 0.3
           }
           
           start_time = time.time()
           
           try:
               response = requests.post(
                   f"{endpoint}/openai/deployments/gpt-4o-vision/chat/completions?api-version=2024-02-15-preview",
                   headers=headers,
                   json=data
               )
               
               end_time = time.time()
               response_time = end_time - start_time
               
               if response.status_code == 200:
                   result = response.json()
                   content = result['choices'][0]['message']['content']
                   tokens_used = result['usage']['total_tokens']
                   
                   test_result = {
                       "test_name": test['name'],
                       "status": "✅ Success",
                       "response_time": f"{response_time:.2f}s",
                       "tokens_used": tokens_used,
                       "image_url": test["image_url"],
                       "analysis": content
                   }
                   
                   print(f"   Status: ✅ Success")
                   print(f"   Response time: {response_time:.2f}s")
                   print(f"   Tokens used: {tokens_used}")
                   print(f"   Analysis: {content[:150]}...")
                   
               else:
                   test_result = {
                       "test_name": test['name'],
                       "status": f"❌ Failed ({response.status_code})",
                       "error": response.text
                   }
                   print(f"   Status: ❌ Failed - {response.status_code}")
               
               results.append(test_result)
               
           except Exception as e:
               print(f"   Status: ❌ Exception - {str(e)}")
               results.append({
                   "test_name": test['name'],
                   "status": f"❌ Exception",
                   "error": str(e)
               })
       
       return results
   
   if __name__ == "__main__":
       print("🚀 Testing GPT-4o Vision Model")
       results = test_vision_model()
       
       # Save results
       with open('vision_model_test_results.json', 'w') as f:
           json.dump(results, f, indent=2)
       
       print("\n📊 Test Summary:")
       for result in results:
           print(f"   {result['test_name']}: {result['status']}")
   ```

2. **Run Vision Model Tests**:
   ```bash
   python test_vision_model.py
   ```

### Step 6: Performance Comparison Analysis

1. **Create Comparison Script**:
   Create `deliverables/model_comparison.py`:
   ```python
   import json
   import matplotlib.pyplot as plt
   import pandas as pd
   
   def analyze_performance():
       """Analyze and compare model performance"""
       
       # Load test results
       with open('text_model_test_results.json', 'r') as f:
           text_results = json.load(f)
       
       with open('vision_model_test_results.json', 'r') as f:
           vision_results = json.load(f)
       
       # Extract performance metrics
       text_metrics = []
       vision_metrics = []
       
       for result in text_results:
           if 'response_time' in result:
               text_metrics.append({
                   'model': 'GPT-4o-mini',
                   'test': result['test_name'],
                   'response_time': float(result['response_time'].replace('s', '')),
                   'tokens_used': result['tokens_used']
               })
       
       for result in vision_results:
           if 'response_time' in result:
               vision_metrics.append({
                   'model': 'GPT-4o-vision',
                   'test': result['test_name'],
                   'response_time': float(result['response_time'].replace('s', '')),
                   'tokens_used': result['tokens_used']
               })
       
       # Create comparison report
       comparison_report = {
           "text_model_performance": {
               "avg_response_time": sum([m['response_time'] for m in text_metrics]) / len(text_metrics),
               "avg_tokens_used": sum([m['tokens_used'] for m in text_metrics]) / len(text_metrics),
               "total_tests": len(text_metrics),
               "success_rate": len([m for m in text_results if 'Success' in m['status']]) / len(text_results) * 100
           },
           "vision_model_performance": {
               "avg_response_time": sum([m['response_time'] for m in vision_metrics]) / len(vision_metrics),
               "avg_tokens_used": sum([m['tokens_used'] for m in vision_metrics]) / len(vision_metrics),
               "total_tests": len(vision_metrics),
               "success_rate": len([m for m in vision_results if 'Success' in m['status']]) / len(vision_results) * 100
           }
       }
       
       # Save comparison report
       with open('model_comparison_report.json', 'w') as f:
           json.dump(comparison_report, f, indent=2)
       
       print("📊 Model Performance Comparison")
       print("=" * 40)
       print(f"Text Model (GPT-4o-mini):")
       print(f"  Avg Response Time: {comparison_report['text_model_performance']['avg_response_time']:.2f}s")
       print(f"  Avg Tokens Used: {comparison_report['text_model_performance']['avg_tokens_used']:.0f}")
       print(f"  Success Rate: {comparison_report['text_model_performance']['success_rate']:.1f}%")
       
       print(f"\nVision Model (GPT-4o-vision):")
       print(f"  Avg Response Time: {comparison_report['vision_model_performance']['avg_response_time']:.2f}s")
       print(f"  Avg Tokens Used: {comparison_report['vision_model_performance']['avg_tokens_used']:.0f}")
       print(f"  Success Rate: {comparison_report['vision_model_performance']['success_rate']:.1f}%")
       
       return comparison_report
   
   if __name__ == "__main__":
       analyze_performance()
   ```

2. **Run Performance Analysis**:
   ```bash
   python model_comparison.py
   ```

## 📝 Documentation Requirements

Create a file `deliverables/endpoint-config.md`:

```markdown
# Task 2: Model Endpoint Deployment Documentation

## Deployed Models Overview

### GPT-4o-mini Text Model
- **Deployment Name**: gpt-4o-mini-text
- **Model Version**: [Version deployed]
- **Deployment Type**: Standard
- **Capacity**: 10 TPM (expandable to 50 TPM)
- **Endpoint URL**: [Your endpoint URL]
- **Status**: ✅ Deployed and tested
- **Use Cases**: Text generation, Q&A, code generation

### GPT-4o Vision Model
- **Deployment Name**: gpt-4o-vision
- **Model Version**: [Version deployed]
- **Deployment Type**: Standard
- **Capacity**: 10 TPM
- **Endpoint URL**: [Your endpoint URL]
- **Status**: ✅ Deployed and tested
- **Use Cases**: Image analysis, OCR, visual Q&A

## Performance Test Results

### Text Model Performance
- **Average Response Time**: [X.XX]s
- **Average Tokens Used**: [XXX] tokens
- **Success Rate**: [XX]%
- **Test Cases Passed**: [X]/3

### Vision Model Performance
- **Average Response Time**: [X.XX]s
- **Average Tokens Used**: [XXX] tokens
- **Success Rate**: [XX]%
- **Test Cases Passed**: [X]/3

## Comparison Analysis
- **Faster Model**: [Text/Vision model comparison]
- **Token Efficiency**: [Analysis of token usage patterns]
- **Use Case Recommendations**: [When to use each model]

## Security Configuration
- **API Keys**: ✅ Stored securely in Key Vault
- **Endpoints**: ✅ Stored securely in Key Vault
- **Access Control**: ✅ Properly configured
- **Content Filtering**: ✅ Default moderate filtering applied

## Cost Estimation
- **Text Model**: ~$[X]/1K tokens
- **Vision Model**: ~$[X]/1K tokens + image processing
- **Estimated Monthly Cost**: $[XX] for development usage

## Next Steps
- ✅ Models ready for prompt flow integration
- ✅ Performance baselines established
- ✅ Security and access controls verified
```

## 📸 Screenshots to Capture

Save screenshots in `deliverables/screenshots/task2/`:

1. **Model Deployments**: Overview of both deployed models
2. **GPT-4o-mini Configuration**: Deployment settings and status
3. **GPT-4o Vision Configuration**: Deployment settings and status
4. **API Keys**: Key generation interface (redact actual keys)
5. **Test Results**: Console output from test scripts
6. **Performance Metrics**: Comparison analysis results
7. **Model Catalog**: Available models and selection process
8. **Deployment Status**: Health and operational status

## ✅ Validation Checklist

Before proceeding to Task 3, ensure:

- [ ] GPT-4o-mini text model is deployed and operational
- [ ] GPT-4o vision model is deployed and operational
- [ ] API keys are generated and stored in Key Vault
- [ ] Text model passes all test cases successfully
- [ ] Vision model passes all test cases successfully
- [ ] Performance comparison analysis is complete
- [ ] Response times are within acceptable ranges
- [ ] Token usage is tracked and documented
- [ ] Security configuration is properly implemented
- [ ] Cost estimation is calculated and reasonable

## 🚨 Troubleshooting

### Common Issues and Solutions:

**Issue**: Model deployment fails
- **Solution**: 
  1. Check quota availability in your region
  2. Verify subscription has access to Azure OpenAI
  3. Try deploying in a different region

**Issue**: API calls return 401 Unauthorized
- **Solution**: 
  1. Verify API key is correct and not expired
  2. Check endpoint URL format
  3. Ensure proper authentication headers

**Issue**: Vision model fails with image processing
- **Solution**: 
  1. Verify image URL is accessible
  2. Check image format is supported
  3. Ensure image size is within limits

**Issue**: High response times
- **Solution**: 
  1. Check model capacity and scaling settings
  2. Verify network connectivity
  3. Consider increasing TPM allocation

## 📚 Additional Resources

- [Azure OpenAI Model Deployments](https://learn.microsoft.com/azure/cognitive-services/openai/how-to/create-resource)
- [GPT-4 Vision API Reference](https://learn.microsoft.com/azure/cognitive-services/openai/reference)
- [Azure AI Studio Model Management](https://learn.microsoft.com/azure/ai-studio/how-to/deploy-models-openai)

## ➡️ Next Step

Once both models are deployed and tested successfully, proceed to [Task 3: Multi-Step Prompt Flow](task3-prompt-flow.md).

---

**💡 Pro Tip**: Start with lower capacity and scale up based on actual usage patterns to optimize costs!