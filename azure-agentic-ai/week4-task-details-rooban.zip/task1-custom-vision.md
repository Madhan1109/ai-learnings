# Task 1: Azure AI Custom Vision Model Training 🖼️

**Estimated Time:** 3 hours  
**Difficulty:** Intermediate  
**Prerequisites:** Week 1 & 2 completed, Azure AI services deployed

## 🎯 Objective
Train a custom image classification model using Azure AI Custom Vision to recognize specific objects or categories in images.

## ⚠️ Important Service Update
**Azure AI Custom Vision** is the recommended service for custom image classification. Avoid using Image Analysis 4.0 custom models, which are being deprecated on March 31, 2025. This task uses the dedicated Azure AI Custom Vision service which remains fully supported.

## 📚 What You'll Learn
- Create and configure Azure AI Custom Vision projects
- Upload and label training images efficiently
- Train custom image classification models using the latest algorithms
- Evaluate model performance with comprehensive metrics
- Test models with new images and analyze confidence scores
- Export models for different platforms and deployment scenarios

## 🔧 Prerequisites
- Azure subscription with Azure AI Custom Vision resource
- Sample image dataset (we'll use a simple 3-class dataset)
- Web browser for Custom Vision portal (customvision.ai)
- Basic understanding of image classification concepts
- Minimum 50 images per class recommended (20 minimum for learning)

## 📋 Step-by-Step Instructions

### Step 1: Create Custom Vision Project (30 minutes)

#### 1.1 Access Azure AI Custom Vision Portal
1. Navigate to [Azure AI Custom Vision Portal](https://www.customvision.ai/)
2. Sign in with your Azure account
3. Click **"New Project"**

> **Note**: Ensure you're using the dedicated Custom Vision service at customvision.ai, not the deprecated Image Analysis 4.0 custom models.

#### 1.2 Configure Project Settings
```
Project Name: "Week3-Object-Classifier"
Description: "Learning project for Week 3 - Azure AI Custom Vision training"
Resource: [Select your Azure AI Custom Vision resource]
Project Types: Classification
Classification Types: Multiclass (single tag per image)
Domains: General [A2] (recommended for learning)
Export Capabilities: Basic platforms (optional)
```

> **Important**: Select your dedicated Azure AI Custom Vision resource, not a general Cognitive Services resource.

#### 1.3 Validation Checklist
- [ ] Project created successfully
- [ ] Connected to your Azure resource
- [ ] Project settings configured correctly
- [ ] Screenshot saved: `deliverables/screenshots/01-project-created.png`

### Step 2: Prepare Training Dataset (45 minutes)

#### 2.1 Download Sample Dataset
We'll use a simple 3-class dataset for learning:
- **Cats** (20 images minimum)
- **Dogs** (20 images minimum)  
- **Birds** (20 images minimum)

You can:
- Use your own photos
- Download from free stock photo sites
- Use the provided sample dataset links below

#### 2.2 Organize Your Images
Create folders on your computer:
```
training-images/
├── cats/
├── dogs/
└── birds/
```

#### 2.3 Image Quality Guidelines
- **Resolution**: At least 256x256 pixels
- **Format**: JPG, PNG, BMP, GIF
- **Size**: Under 6MB per image
- **Variety**: Different angles, lighting, backgrounds
- **Quality**: Clear, well-lit images

#### 2.4 Validation Checklist
- [ ] At least 20 images per category collected
- [ ] Images organized in folders
- [ ] Image quality meets guidelines
- [ ] Screenshot saved: `deliverables/screenshots/02-dataset-organized.png`

### Step 3: Upload and Label Images (60 minutes)

#### 3.1 Upload Cat Images
1. In Custom Vision portal, click **"Add images"**
2. Select all cat images from your `cats/` folder
3. Add tag: `cat`
4. Click **"Upload [X] files"**
5. Wait for upload completion

#### 3.2 Upload Dog Images
1. Click **"Add images"** again
2. Select all dog images from your `dogs/` folder
3. Add tag: `dog`
4. Click **"Upload [X] files"**

#### 3.3 Upload Bird Images
1. Click **"Add images"** again
2. Select all bird images from your `birds/` folder
3. Add tag: `bird`
4. Click **"Upload [X] files"**

#### 3.4 Review Tagged Images
1. Click on each tag to review images
2. Verify all images are correctly tagged
3. Remove any incorrectly labeled images
4. Ensure balanced dataset (similar number of images per class)

#### 3.5 Validation Checklist
- [ ] All images uploaded successfully
- [ ] Each image properly tagged
- [ ] Balanced dataset across all classes
- [ ] No mislabeled images
- [ ] Screenshot saved: `deliverables/screenshots/03-images-uploaded.png`

### Step 4: Train the Model (30 minutes)

#### 4.1 Start Training
1. Click the green **"Train"** button
2. Select **"Quick Training"** (for learning purposes)
3. Wait for training to complete (usually 2-10 minutes)

#### 4.2 Monitor Training Progress
- Training status will show in the **Iterations** tab
- You'll see a progress indicator
- Training typically completes quickly for small datasets

#### 4.3 Validation Checklist
- [ ] Training initiated successfully
- [ ] Training completed without errors
- [ ] New iteration created
- [ ] Screenshot saved: `deliverables/screenshots/04-training-complete.png`

### Step 5: Evaluate Model Performance (45 minutes)

#### 5.1 Review Performance Metrics
After training, you'll see:
- **Precision**: How accurate your positive predictions are
- **Recall**: How many actual positives you correctly identified
- **AP (Average Precision)**: Overall model performance

#### 5.2 Analyze Per-Class Performance
1. Click on **"Performance"** tab
2. Review metrics for each class (cat, dog, bird)
3. Identify which classes perform best/worst

#### 5.3 Expected Results for Learning
- **Good Performance**: 80%+ precision and recall
- **Acceptable**: 70-80% (can improve with more data)
- **Needs Improvement**: <70% (add more diverse images)

#### 5.4 Document Performance
Create a simple performance summary:
```markdown
# Model Performance Summary

## Overall Metrics
- Precision: [X]%
- Recall: [X]%
- Average Precision: [X]%

## Per-Class Performance
- Cat: Precision [X]%, Recall [X]%
- Dog: Precision [X]%, Recall [X]%
- Bird: Precision [X]%, Recall [X]%

## Observations
- Best performing class: [class name]
- Needs improvement: [class name]
- Overall assessment: [Good/Acceptable/Needs Improvement]
```

#### 5.5 Validation Checklist
- [ ] Performance metrics reviewed
- [ ] Per-class analysis completed
- [ ] Performance summary documented
- [ ] Screenshot saved: `deliverables/screenshots/05-performance-metrics.png`

### Step 6: Test the Model (30 minutes)

#### 6.1 Quick Test with Portal
1. Click **"Quick Test"** button
2. Upload a new image (not from training set)
3. Review prediction results
4. Test with 2-3 images per class

#### 6.2 Analyze Test Results
For each test image, note:
- **Predicted class**: What the model predicted
- **Confidence score**: How confident the model is (0-100%)
- **Correct prediction**: Yes/No

#### 6.3 Test Results Documentation
```markdown
# Test Results

## Test Image 1: [filename]
- Actual class: [cat/dog/bird]
- Predicted class: [cat/dog/bird]
- Confidence: [X]%
- Correct: [Yes/No]

## Test Image 2: [filename]
- Actual class: [cat/dog/bird]
- Predicted class: [cat/dog/bird]
- Confidence: [X]%
- Correct: [Yes/No]

[Continue for all test images...]

## Summary
- Total tests: [X]
- Correct predictions: [X]
- Accuracy: [X]%
```

#### 6.4 Validation Checklist
- [ ] Quick test performed with new images
- [ ] Test results documented
- [ ] Model accuracy calculated
- [ ] Screenshot saved: `deliverables/screenshots/06-test-results.png`

## 📊 Deliverables

Save all deliverables in `docs/week3/deliverables/custom-vision-model/`:

### Required Files
1. **`model-performance.md`** - Performance metrics and analysis
2. **`test-results.md`** - Test results documentation
3. **`training-summary.md`** - Overall training experience summary

### Screenshots
1. `01-project-created.png` - Custom Vision project setup
2. `02-dataset-organized.png` - Organized training images
3. `03-images-uploaded.png` - Images uploaded and tagged
4. `04-training-complete.png` - Training completion
5. `05-performance-metrics.png` - Model performance metrics
6. `06-test-results.png` - Quick test results

### Training Summary Template
```markdown
# Custom Vision Training Summary

## Project Details
- Project Name: Week3-Object-Classifier
- Classes: Cat, Dog, Bird
- Total Images: [X]
- Training Date: [Date]

## Dataset Composition
- Cat images: [X]
- Dog images: [X]
- Bird images: [X]

## Model Performance
- Overall Precision: [X]%
- Overall Recall: [X]%
- Average Precision: [X]%

## Key Learnings
1. [What you learned about data quality]
2. [What you learned about model training]
3. [What you learned about evaluation]

## Next Steps
- [How you would improve the model]
- [Additional classes you might add]
- [Real-world applications you envision]
```

## ✅ Success Criteria

- [ ] Custom Vision project created and configured
- [ ] Minimum 60 images uploaded (20 per class)
- [ ] Model trained successfully
- [ ] Model achieves 70%+ precision and recall
- [ ] Quick test performed with new images
- [ ] All deliverables completed and documented
- [ ] Screenshots captured for all major steps

## 🚨 Troubleshooting

### Common Issues

**Training Fails**
- Check image formats (JPG, PNG, BMP, GIF only)
- Ensure images are under 6MB
- Verify you have at least 5 images per tag

**Low Performance**
- Add more diverse images per class
- Check for mislabeled images
- Ensure good image quality and variety

**Upload Issues**
- Check internet connection
- Try uploading smaller batches
- Verify image file sizes

**Can't Access Custom Vision Portal**
- Verify Azure subscription is active
- Check if Custom Vision resource is properly deployed
- Try incognito/private browsing mode

### Getting Help
- Review [Custom Vision Documentation](https://learn.microsoft.com/azure/ai-services/custom-vision-service/)
- Check Azure portal for resource status
- Verify billing and quotas

## 🎓 Learning Questions

After completing this task, reflect on:

1. **Data Quality**: How did image quality and variety affect your model's performance?
2. **Class Balance**: What happened when you had unequal numbers of images per class?
3. **Evaluation**: What do precision and recall tell you about your model?
4. **Real-world Applications**: Where could you use this type of custom vision model?
5. **Improvements**: How would you improve your model's performance?

## ➡️ Next Steps

Proceed to [Task 2: Document Intelligence Custom Model](task2-document-intelligence.md) to learn about training custom document processing models.

---

**💡 Pro Tip**: The key to good custom vision models is diverse, high-quality training data. Take time to collect varied images for better results! 