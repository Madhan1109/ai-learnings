# Task 4: Model Registration & Versioning 📋

**Estimated Time:** 1.5 hours  
**Difficulty:** Intermediate  
**Prerequisites:** Week 3 Tasks 1-3 completed (trained custom models)

## 🎯 Objective
Learn to properly register, version, and manage your custom AI models in Azure AI Foundry for production readiness and governance.

## 📚 What You'll Learn
- Register custom models in Azure AI Foundry Model Registry
- Implement proper model versioning strategies
- Add metadata and tags for model governance
- Create model lineage and tracking
- Manage model lifecycle and deployment stages

## 🔧 Prerequisites
- Completed Tasks 1-3 (Custom Vision, Document Intelligence, OpenAI fine-tuning)
- Access to Azure AI Foundry
- Understanding of model lifecycle management concepts

## 📋 Step-by-Step Instructions

### Step 1: Access Azure AI Foundry Model Registry (15 minutes)

#### 1.1 Navigate to Model Registry
1. Go to [Azure AI Foundry](https://ai.azure.com/)
2. Sign in and select your project from Week 2
3. Navigate to **"Models + endpoints"** → **"Model registry"**

#### 1.2 Explore Model Registry Interface
1. Review existing models (if any)
2. Understand the registry structure
3. Note available actions (register, version, deploy)

#### 1.3 Validation Checklist
- [ ] Successfully accessed Azure AI Foundry
- [ ] Model registry section accessible
- [ ] Interface familiarized
- [ ] Screenshot saved: `deliverables/screenshots/01-registry-access.png`

### Step 2: Register Custom Vision Model (25 minutes)

#### 2.1 Prepare Model Information
From Task 1, gather:
- Model performance metrics
- Training dataset details
- Model export files (if available)
- Training configuration

#### 2.2 Register Custom Vision Model
1. Click **"Register model"** in the registry
2. Choose **"From local files"** or **"From datastore"**
3. Fill in model details:

```
Model name: week3-custom-vision-classifier
Version: 1.0.0
Description: Custom image classifier for cats, dogs, and birds trained in Week 3
Model type: Custom Vision
Framework: Custom Vision Service
```

#### 2.3 Add Model Metadata
Include comprehensive metadata:
```yaml
Training Details:
  - Dataset: 60+ images (cats, dogs, birds)
  - Training Date: [Date]
  - Training Duration: [X] minutes
  - Performance: Precision [X]%, Recall [X]%

Model Configuration:
  - Domain: General [A2]
  - Classification Type: Multiclass
  - Classes: cat, dog, bird
  - Training Method: Quick Training

Usage Information:
  - Input: Image files (JPG, PNG, BMP, GIF)
  - Output: Classification with confidence scores
  - Use Case: Learning project for image classification
```

#### 2.4 Add Tags for Organization
Add relevant tags:
- `project:week3`
- `type:classification`
- `domain:computer-vision`
- `status:experimental`
- `accuracy:high` (if >80%)

#### 2.5 Validation Checklist
- [ ] Custom Vision model registered successfully
- [ ] Comprehensive metadata added
- [ ] Appropriate tags applied
- [ ] Model version set to 1.0.0
- [ ] Screenshot saved: `deliverables/screenshots/02-cv-model-registered.png`

### Step 3: Register Document Intelligence Model (25 minutes)

#### 3.1 Prepare Document Intelligence Model Info
From Task 2, gather:
- Model ID from Document Intelligence Studio
- Training document count and types
- Field extraction accuracy
- Model configuration details

#### 3.2 Register Document Intelligence Model
1. Click **"Register model"** again
2. Fill in model details:

```
Model name: week3-invoice-extractor
Version: 1.0.0
Description: Custom Document Intelligence model for invoice data extraction
Model type: Document Intelligence
Framework: Azure Document Intelligence
```

#### 3.3 Add Detailed Metadata
```yaml
Training Details:
  - Document Type: Invoices
  - Training Documents: [X] documents
  - Training Date: [Date]
  - Model ID: [Document Intelligence Model ID]

Extracted Fields:
  - invoice_number (String)
  - invoice_date (Date)
  - vendor_name (String)
  - total_amount (Number)
  - customer_name (String)

Performance Metrics:
  - Field Extraction Accuracy: [X]%
  - Average Confidence Score: [X.XX]
  - Test Document Results: [X/X] fields correct

Usage Information:
  - Input: PDF, JPEG, PNG, BMP, TIFF documents
  - Output: Structured JSON with extracted fields
  - Use Case: Invoice processing and data extraction
```

#### 3.4 Add Appropriate Tags
- `project:week3`
- `type:extraction`
- `domain:document-intelligence`
- `status:experimental`
- `document-type:invoice`

#### 3.5 Validation Checklist
- [ ] Document Intelligence model registered
- [ ] Model ID and metadata documented
- [ ] Field extraction details included
- [ ] Performance metrics added
- [ ] Screenshot saved: `deliverables/screenshots/03-di-model-registered.png`

### Step 4: Register Fine-tuned OpenAI Model (25 minutes)

#### 4.1 Prepare Fine-tuned Model Information
From Task 3, gather:
- Fine-tuned model ID
- Training dataset details
- Training metrics (loss, cost, duration)
- Deployment information

#### 4.2 Register Fine-tuned Model
1. Register the fine-tuned model:

```
Model name: week3-customer-support-bot
Version: 1.0.0
Description: Fine-tuned GPT-3.5-turbo for TechCorp customer support
Model type: Language Model
Framework: Azure OpenAI
```

#### 4.3 Add Comprehensive Metadata
```yaml
Base Model Information:
  - Base Model: gpt-35-turbo
  - Fine-tuning Job ID: [Job ID]
  - Training Date: [Date]

Training Details:
  - Training Examples: [X] JSONL examples
  - Training Categories: Password, Product, Billing, Technical, General
  - Training Duration: [X] minutes
  - Training Cost: $[X.XX]

Performance Metrics:
  - Training Loss: [X.XX]
  - Validation Loss: [X.XX] (if available)
  - Training Tokens: [X,XXX]

Model Capabilities:
  - Use Case: Customer support chatbot
  - Domain: TechCorp customer service
  - Input: Customer questions and requests
  - Output: Contextual support responses

Deployment Information:
  - Deployment Name: week3-support-bot-deployment
  - Rate Limit: 10K tokens/minute
  - Content Filter: Default
```

#### 4.4 Add Specialized Tags
- `project:week3`
- `type:language-model`
- `domain:customer-support`
- `status:experimental`
- `base-model:gpt-35-turbo`
- `fine-tuned:true`

#### 4.5 Validation Checklist
- [ ] Fine-tuned OpenAI model registered
- [ ] Training metrics documented
- [ ] Deployment details included
- [ ] Comprehensive metadata added
- [ ] Screenshot saved: `deliverables/screenshots/04-openai-model-registered.png`

### Step 5: Implement Model Versioning Strategy (20 minutes)

#### 5.1 Create Version 1.1 of Custom Vision Model
Simulate an improved version:
1. Select your Custom Vision model
2. Click **"Create new version"**
3. Set version to `1.1.0`
4. Update description: "Improved version with additional training data"

#### 5.2 Document Version Changes
```markdown
# Model Version History

## week3-custom-vision-classifier

### Version 1.1.0
- **Changes**: Added 20 more training images per class
- **Performance**: Improved precision from [X]% to [Y]%
- **Date**: [Date]
- **Notes**: Better handling of edge cases and lighting conditions

### Version 1.0.0
- **Initial Release**: Basic 3-class classifier
- **Performance**: Precision [X]%, Recall [X]%
- **Date**: [Date]
- **Notes**: Initial training with 60 images total
```

#### 5.3 Create Versioning Guidelines
Document your versioning strategy:
```markdown
# Model Versioning Guidelines

## Version Number Format: MAJOR.MINOR.PATCH

### MAJOR (X.0.0)
- Breaking changes to model interface
- Complete retraining with different architecture
- Significant changes to input/output format

### MINOR (0.X.0)
- New features or capabilities
- Performance improvements
- Additional training data
- Non-breaking enhancements

### PATCH (0.0.X)
- Bug fixes
- Minor adjustments
- Documentation updates
- Metadata corrections

## Version Lifecycle
1. **Experimental**: Initial development and testing
2. **Staging**: Ready for pre-production testing
3. **Production**: Deployed and serving traffic
4. **Deprecated**: Scheduled for retirement
5. **Archived**: No longer maintained
```

#### 5.4 Validation Checklist
- [ ] Model version 1.1.0 created
- [ ] Version changes documented
- [ ] Versioning guidelines established
- [ ] Version history maintained
- [ ] Screenshot saved: `deliverables/screenshots/05-versioning-strategy.png`

### Step 6: Create Model Governance Documentation (20 minutes)

#### 6.1 Create Model Registry Summary
Document all registered models:
```markdown
# Week 3 Model Registry Summary

## Registered Models Overview

| Model Name | Version | Type | Status | Performance | Use Case |
|------------|---------|------|--------|-------------|----------|
| week3-custom-vision-classifier | 1.1.0 | Classification | Experimental | [X]% accuracy | Image classification |
| week3-invoice-extractor | 1.0.0 | Extraction | Experimental | [X]% field accuracy | Invoice processing |
| week3-customer-support-bot | 1.0.0 | Language Model | Experimental | Training loss [X.XX] | Customer support |

## Model Lineage
- **Custom Vision**: Trained from scratch using Custom Vision Service
- **Document Intelligence**: Custom template model trained on invoice samples
- **OpenAI Fine-tuning**: Fine-tuned from gpt-35-turbo base model

## Governance Policies
- All models tagged with project identifier
- Performance metrics documented for each version
- Training data sources tracked and documented
- Model lifecycle status maintained
```

#### 6.2 Create Model Cards Preview
For each model, create a brief model card:
```markdown
# Model Card: week3-custom-vision-classifier v1.1.0

## Model Overview
- **Purpose**: Educational image classification
- **Type**: Multi-class classification
- **Classes**: cat, dog, bird

## Performance
- **Accuracy**: [X]%
- **Precision**: [X]%
- **Recall**: [X]%

## Training Data
- **Size**: 80+ images
- **Source**: Mixed (personal photos, stock images)
- **Quality**: High resolution, varied conditions

## Limitations
- Limited to 3 classes only
- Performance may vary with different lighting
- Not suitable for production use

## Ethical Considerations
- Training data reviewed for bias
- No sensitive or personal information
- Educational use only
```

#### 6.3 Validation Checklist
- [ ] Model registry summary created
- [ ] Model lineage documented
- [ ] Governance policies defined
- [ ] Model cards previewed
- [ ] Screenshot saved: `deliverables/screenshots/06-governance-docs.png`

## 📊 Deliverables

Save all deliverables in `docs/week3/deliverables/model-management/`:

### Required Files
1. **`model-registry-summary.md`** - Complete registry overview
2. **`versioning-strategy.md`** - Model versioning guidelines
3. **`model-lineage.md`** - Model development lineage
4. **`governance-policies.md`** - Model governance framework

### Screenshots
1. `01-registry-access.png` - Model registry access
2. `02-cv-model-registered.png` - Custom Vision model registered
3. `03-di-model-registered.png` - Document Intelligence model registered
4. `04-openai-model-registered.png` - OpenAI model registered
5. `05-versioning-strategy.png` - Versioning implementation
6. `06-governance-docs.png` - Governance documentation

### Model Registry Summary Template
```markdown
# Azure AI Foundry Model Registry Summary

## Project Information
- Project: Week 3 Custom Model Development
- Registry Location: Azure AI Foundry
- Total Models Registered: 3
- Registration Date: [Date]

## Model Inventory

### 1. Custom Vision Classifier
- **Name**: week3-custom-vision-classifier
- **Current Version**: 1.1.0
- **Type**: Image Classification
- **Status**: Experimental
- **Performance**: [X]% accuracy
- **Last Updated**: [Date]

### 2. Document Intelligence Extractor
- **Name**: week3-invoice-extractor
- **Current Version**: 1.0.0
- **Type**: Document Processing
- **Status**: Experimental
- **Performance**: [X]% field extraction accuracy
- **Last Updated**: [Date]

### 3. Fine-tuned Language Model
- **Name**: week3-customer-support-bot
- **Current Version**: 1.0.0
- **Type**: Language Model
- **Status**: Experimental
- **Performance**: Training loss [X.XX]
- **Last Updated**: [Date]

## Registry Benefits Realized
1. **Centralized Management**: All models in one location
2. **Version Control**: Proper versioning and change tracking
3. **Metadata Management**: Rich metadata for each model
4. **Governance**: Tags and policies for organization
5. **Lineage Tracking**: Clear model development history

## Next Steps
1. Move models to staging environment
2. Implement automated testing
3. Create production deployment pipeline
4. Establish monitoring and alerting
```

## ✅ Success Criteria

- [ ] All 3 custom models registered in Azure AI Foundry
- [ ] Comprehensive metadata added for each model
- [ ] Appropriate tags applied for organization
- [ ] Model versioning strategy implemented
- [ ] Version 1.1.0 created for at least one model
- [ ] Governance documentation completed
- [ ] Model lineage tracked and documented
- [ ] All deliverables completed with screenshots

## 🚨 Troubleshooting

### Common Issues

**Model Registration Fails**
- Check Azure AI Foundry permissions
- Verify model files are accessible
- Ensure proper metadata format
- Check for naming conflicts

**Version Creation Issues**
- Verify original model exists
- Check version number format
- Ensure proper permissions
- Review version naming conventions

**Metadata Not Saving**
- Check character limits for fields
- Verify special characters in metadata
- Ensure proper YAML/JSON format
- Try shorter descriptions if needed

**Tags Not Applying**
- Check tag naming conventions
- Verify no special characters
- Ensure tags are not too long
- Try applying tags one at a time

### Getting Help
- Review [Azure AI Foundry Documentation](https://learn.microsoft.com/azure/ai-studio/)
- Check model registry limits and quotas
- Verify subscription permissions

## 🎓 Learning Questions

After completing this task, reflect on:

1. **Organization**: How does model registry help organize your AI assets?
2. **Versioning**: Why is proper versioning crucial for model management?
3. **Metadata**: What metadata is most important for model governance?
4. **Lifecycle**: How would you manage models through their entire lifecycle?
5. **Collaboration**: How does model registry enable team collaboration?

## ➡️ Next Steps

Proceed to [Task 5: Model Cards & Documentation](task5-model-documentation.md) to create comprehensive documentation for your registered models.

---

**💡 Pro Tip**: Good model management starts with consistent naming, comprehensive metadata, and clear versioning strategies. Invest time in organization now to save time later! 