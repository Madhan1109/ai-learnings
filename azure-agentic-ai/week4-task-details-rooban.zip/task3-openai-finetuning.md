# Task 3: Azure OpenAI Fine-tuning 🤖

**Estimated Time:** 3 hours  
**Difficulty:** Advanced  
**Prerequisites:** Week 1 & 2 completed, Azure OpenAI service deployed

## 🎯 Objective
Fine-tune an Azure OpenAI model with custom data to create a specialized model for your specific use case.

## 📚 What You'll Learn
- Prepare training data in JSONL format for fine-tuning
- Create and manage fine-tuning jobs in Azure OpenAI Studio
- Monitor training progress and evaluate results
- Deploy and test fine-tuned models
- Compare performance between base and fine-tuned models

## 🔧 Prerequisites
- Azure OpenAI resource with fine-tuning capabilities
- Access to Azure OpenAI Studio
- Understanding of JSON format and data preparation
- Sample dataset for fine-tuning (we'll create one for learning)

## 📋 Step-by-Step Instructions

### Step 1: Access Azure OpenAI Studio (15 minutes)

#### 1.1 Navigate to Azure OpenAI Studio
1. Go to [Azure OpenAI Studio](https://oai.azure.com/)
2. Sign in with your Azure account
3. Select your subscription and OpenAI resource

#### 1.2 Verify Fine-tuning Access
1. Navigate to **"Fine-tuning"** in the left menu
2. Check if fine-tuning is available for your resource
3. Review available base models for fine-tuning

#### 1.3 Validation Checklist
- [ ] Successfully accessed Azure OpenAI Studio
- [ ] Fine-tuning section accessible
- [ ] Base models available for fine-tuning
- [ ] Screenshot saved: `deliverables/screenshots/01-studio-access.png`

### Step 2: Prepare Training Dataset (60 minutes)

#### 2.1 Choose Use Case
For this learning exercise, we'll create a **Customer Support Chatbot** that provides specific responses for a fictional company. You can adapt this to:
- Product recommendations
- Technical support
- FAQ responses
- Content generation

#### 2.2 Understand JSONL Format
Fine-tuning data must be in JSONL (JSON Lines) format:
```json
{"messages": [{"role": "system", "content": "You are a helpful customer support agent for TechCorp."}, {"role": "user", "content": "How do I reset my password?"}, {"role": "assistant", "content": "To reset your password: 1) Go to login page 2) Click 'Forgot Password' 3) Enter your email 4) Check your email for reset link 5) Follow the instructions in the email. If you need further help, contact support at support@techcorp.com"}]}
```

#### 2.3 Create Training Examples
Create 20-30 training examples covering different scenarios:

**Example 1: Password Reset**
```json
{"messages": [{"role": "system", "content": "You are a helpful customer support agent for TechCorp."}, {"role": "user", "content": "I forgot my password, what should I do?"}, {"role": "assistant", "content": "No problem! To reset your TechCorp password: 1) Visit our login page 2) Click 'Forgot Password' 3) Enter your registered email address 4) Check your email for a reset link 5) Click the link and create a new password. The reset link expires in 24 hours. Need more help? Contact us at support@techcorp.com or call 1-800-TECH-HELP."}]}
```

**Example 2: Product Information**
```json
{"messages": [{"role": "system", "content": "You are a helpful customer support agent for TechCorp."}, {"role": "user", "content": "What are the features of TechCorp Pro?"}, {"role": "assistant", "content": "TechCorp Pro includes: • Advanced analytics dashboard • 24/7 priority support • API access with 10,000 calls/month • Custom integrations • Advanced security features • Dedicated account manager. Pro costs $99/month with a 14-day free trial. Would you like me to help you start your trial?"}]}
```

#### 2.4 Create Complete Training File
Create a file called `training_data.jsonl` with 20-30 examples covering:
- Password/account issues (5-7 examples)
- Product information (5-7 examples)
- Billing questions (5-7 examples)
- Technical support (5-7 examples)
- General inquiries (3-5 examples)

#### 2.5 Data Quality Guidelines
- **Consistency**: Use the same system message across examples
- **Variety**: Cover different ways users might ask the same question
- **Quality**: Provide helpful, accurate responses
- **Length**: Keep responses concise but informative
- **Format**: Ensure valid JSON structure

#### 2.6 Validation Checklist
- [ ] Training dataset created in JSONL format
- [ ] 20-30 high-quality examples included
- [ ] Consistent system message used
- [ ] Various scenarios covered
- [ ] JSON format validated
- [ ] File saved as `training_data.jsonl`

### Step 3: Upload Training Data (20 minutes)

#### 3.1 Navigate to Data Files
1. In Azure OpenAI Studio, go to **"Management"** → **"Data files"**
2. Click **"Upload files"**

#### 3.2 Upload Training File
1. Select your `training_data.jsonl` file
2. Choose purpose: **"fine-tune"**
3. Click **"Upload"**
4. Wait for upload and validation to complete

#### 3.3 Verify Data Upload
1. Check that file appears in data files list
2. Verify file status shows as **"Processed"**
3. Review any validation warnings or errors

#### 3.4 Validation Checklist
- [ ] Training file uploaded successfully
- [ ] File status shows as "Processed"
- [ ] No critical validation errors
- [ ] File visible in data files list
- [ ] Screenshot saved: `deliverables/screenshots/02-data-uploaded.png`

### Step 4: Create Fine-tuning Job (25 minutes)

#### 4.1 Start New Fine-tuning Job
1. Navigate to **"Fine-tuning"** section
2. Click **"Create new fine-tuning job"**

#### 4.2 Configure Fine-tuning Settings
```
Job name: week3-customer-support-bot
Base model: gpt-35-turbo (recommended for learning)
Training data: [Select your uploaded file]
Validation data: [Leave empty for now]
Task type: Chat completion
```

#### 4.3 Advanced Settings (Optional)
For learning purposes, use default settings:
- **Learning rate**: Auto
- **Batch size**: Auto  
- **Number of epochs**: Auto
- **Seed**: [Leave empty]

#### 4.4 Review and Submit
1. Review all settings
2. Estimate training cost (usually $1-5 for small datasets)
3. Click **"Submit"** to start fine-tuning

#### 4.5 Validation Checklist
- [ ] Fine-tuning job created successfully
- [ ] Job appears in fine-tuning list
- [ ] Training started (status: "Running")
- [ ] Job ID noted for tracking
- [ ] Screenshot saved: `deliverables/screenshots/03-finetuning-started.png`

### Step 5: Monitor Training Progress (30 minutes)

#### 5.1 Track Job Status
1. Monitor job status in the fine-tuning list
2. Status progression: Pending → Running → Succeeded/Failed
3. Training typically takes 10-30 minutes for small datasets

#### 5.2 Review Training Metrics
Once training completes, you'll see:
- **Training loss**: How well the model learned from training data
- **Validation loss**: Model performance on validation data
- **Training tokens**: Number of tokens processed
- **Training cost**: Actual cost incurred

#### 5.3 Document Training Results
```markdown
# Fine-tuning Training Results

## Job Details
- Job ID: [ID]
- Job Name: week3-customer-support-bot
- Base Model: gpt-35-turbo
- Status: [Succeeded/Failed]
- Training Duration: [X] minutes

## Training Metrics
- Training Loss: [X.XX]
- Validation Loss: [X.XX] (if available)
- Training Tokens: [X,XXX]
- Training Cost: $[X.XX]

## Training Data
- Training Examples: [X]
- File Size: [X] KB
- Data Quality: [Good/Fair/Poor]
```

#### 5.4 Validation Checklist
- [ ] Training completed successfully
- [ ] Training metrics reviewed
- [ ] Training results documented
- [ ] Fine-tuned model available for deployment
- [ ] Screenshot saved: `deliverables/screenshots/04-training-complete.png`

### Step 6: Deploy Fine-tuned Model (20 minutes)

#### 6.1 Create Model Deployment
1. Navigate to **"Deployments"** section
2. Click **"Create new deployment"**
3. Select your fine-tuned model from the list

#### 6.2 Configure Deployment
```
Deployment name: week3-support-bot-deployment
Model: [Your fine-tuned model]
Model version: [Latest version]
Deployment type: Standard
Tokens per minute rate limit: 10K (for learning)
Content filter: Default
```

#### 6.3 Deploy Model
1. Review deployment settings
2. Click **"Create"** to deploy
3. Wait for deployment to complete (2-5 minutes)

#### 6.4 Validation Checklist
- [ ] Deployment created successfully
- [ ] Model deployed and available
- [ ] Deployment endpoint accessible
- [ ] Rate limits configured appropriately
- [ ] Screenshot saved: `deliverables/screenshots/05-model-deployed.png`

### Step 7: Test Fine-tuned Model (50 minutes)

#### 7.1 Test in Chat Playground
1. Navigate to **"Chat"** playground
2. Select your deployed fine-tuned model
3. Set system message: "You are a helpful customer support agent for TechCorp."

#### 7.2 Run Test Scenarios
Test with questions similar to your training data:

**Test 1: Password Reset**
- User: "I can't log into my account"
- Expected: Specific TechCorp password reset instructions

**Test 2: Product Information**
- User: "Tell me about your Pro plan"
- Expected: Detailed TechCorp Pro features and pricing

**Test 3: Billing Question**
- User: "How do I cancel my subscription?"
- Expected: TechCorp-specific cancellation process

#### 7.3 Compare with Base Model
1. Test the same questions with the base gpt-35-turbo model
2. Compare responses for:
   - Specificity to TechCorp
   - Accuracy of information
   - Consistency with training data
   - Overall helpfulness

#### 7.4 Document Test Results
```markdown
# Fine-tuned Model Test Results

## Test Scenario 1: Password Reset
**Question**: "I can't log into my account"

**Base Model Response**:
[Response from base model]

**Fine-tuned Model Response**:
[Response from fine-tuned model]

**Analysis**:
- Specificity: [Better/Same/Worse]
- Accuracy: [Better/Same/Worse]
- Helpfulness: [Better/Same/Worse]

## Test Scenario 2: Product Information
[Similar format for each test]

## Overall Assessment
- Fine-tuning effectiveness: [Excellent/Good/Fair/Poor]
- Key improvements: [List improvements]
- Areas for enhancement: [List areas to improve]
```

#### 7.5 Validation Checklist
- [ ] Fine-tuned model tested in playground
- [ ] Multiple test scenarios completed
- [ ] Comparison with base model performed
- [ ] Test results documented
- [ ] Model performance evaluated
- [ ] Screenshot saved: `deliverables/screenshots/06-model-testing.png`

## 📊 Deliverables

Save all deliverables in `docs/week3/deliverables/openai-finetuning/`:

### Required Files
1. **`training_data.jsonl`** - Your training dataset
2. **`training-results.md`** - Training metrics and analysis
3. **`model-comparison.md`** - Base vs fine-tuned model comparison
4. **`finetuning-summary.md`** - Overall fine-tuning experience

### Screenshots
1. `01-studio-access.png` - Azure OpenAI Studio access
2. `02-data-uploaded.png` - Training data uploaded
3. `03-finetuning-started.png` - Fine-tuning job started
4. `04-training-complete.png` - Training completed
5. `05-model-deployed.png` - Model deployed
6. `06-model-testing.png` - Model testing results

### Fine-tuning Summary Template
```markdown
# Azure OpenAI Fine-tuning Summary

## Project Overview
- Use Case: Customer Support Chatbot for TechCorp
- Base Model: gpt-35-turbo
- Training Examples: [X]
- Training Duration: [X] minutes
- Training Cost: $[X.XX]

## Dataset Details
- Format: JSONL
- Total Examples: [X]
- Categories Covered:
  - Password/Account Issues: [X] examples
  - Product Information: [X] examples
  - Billing Questions: [X] examples
  - Technical Support: [X] examples
  - General Inquiries: [X] examples

## Training Results
- Final Training Loss: [X.XX]
- Training Status: [Succeeded/Failed]
- Model ID: [Generated ID]
- Deployment Name: week3-support-bot-deployment

## Performance Evaluation
### Improvements Over Base Model
1. [Specific improvement 1]
2. [Specific improvement 2]
3. [Specific improvement 3]

### Areas for Enhancement
1. [Area needing improvement 1]
2. [Area needing improvement 2]

## Key Learnings
1. [What you learned about data preparation]
2. [What you learned about fine-tuning process]
3. [What you learned about model evaluation]

## Real-world Applications
- [How this could be used in production]
- [Other use cases for fine-tuning]
- [Business value of custom models]
```

## ✅ Success Criteria

- [ ] Training dataset created with 20+ examples in JSONL format
- [ ] Data uploaded and validated successfully
- [ ] Fine-tuning job completed without errors
- [ ] Fine-tuned model deployed successfully
- [ ] Model tested and compared with base model
- [ ] Clear improvements demonstrated in specific use case
- [ ] All deliverables completed and documented
- [ ] Screenshots captured for all major steps

## 🚨 Troubleshooting

### Common Issues

**Data Upload Fails**
- Check JSONL format validity
- Ensure proper JSON structure in each line
- Verify file encoding (UTF-8)
- Check for special characters

**Training Job Fails**
- Review data validation errors
- Ensure sufficient training examples (minimum 10)
- Check for data quality issues
- Verify base model availability

**Low Fine-tuning Performance**
- Increase training data quantity and quality
- Ensure consistent system messages
- Review data diversity and coverage
- Consider different base model

**Deployment Issues**
- Check quota limits for deployments
- Verify model training completed successfully
- Ensure proper permissions
- Try different deployment configuration

### Getting Help
- Review [Azure OpenAI Fine-tuning Documentation](https://learn.microsoft.com/azure/ai-services/openai/how-to/fine-tuning)
- Check Azure portal for service status
- Verify billing and quotas

## 🎓 Learning Questions

After completing this task, reflect on:

1. **Data Quality**: How did the quality and quantity of training data affect results?
2. **Use Case Specificity**: How well did the fine-tuned model adapt to your specific use case?
3. **Cost vs. Benefit**: Was the improvement worth the training cost and effort?
4. **Production Readiness**: What would you need to consider for production deployment?
5. **Ethical Considerations**: What responsible AI practices should you follow?

## ➡️ Next Steps

Proceed to [Task 4: Model Registration & Versioning](task4-model-management.md) to learn about managing and versioning your custom models.

---

**💡 Pro Tip**: Fine-tuning works best with high-quality, consistent training data. Start small, test thoroughly, and iterate based on results! 