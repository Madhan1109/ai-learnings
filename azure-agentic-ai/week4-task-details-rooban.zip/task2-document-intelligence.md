# Task 2: Document Intelligence Custom Neural Model 📄

**Estimated Time:** 2.5 hours  
**Difficulty:** Intermediate  
**Prerequisites:** Week 1 & 2 completed, Document Intelligence service deployed

## 🎯 Objective
Create a custom Document Intelligence neural model to extract specific information from structured documents like forms, invoices, or receipts using the latest v4.0 capabilities.

## 🆕 Latest Features (v4.0 GA)
This task uses Document Intelligence v4.0 (2024-11-30 GA) which includes:
- **Custom neural models** with improved accuracy
- **Signature detection** capabilities
- **Overlapping fields** support
- **Table, row, and cell confidence** scores
- **Enhanced training** with up to 50,000 pages

## 📚 What You'll Learn
- Create custom neural document models using Document Intelligence Studio
- Label document fields efficiently with advanced labeling tools
- Train extraction models with improved neural algorithms
- Test custom models and analyze confidence scores
- Explore signature detection and overlapping fields
- Understand table, row, and cell confidence scores
- Manage and deploy custom models

## 🔧 Prerequisites
- Azure Document Intelligence resource v4.0 (from Week 1)
- Document Intelligence Studio access (documentintelligence.ai.azure.com)
- Sample documents for training (2-15 similar documents for neural models)
- Azure Storage account for training data
- Basic understanding of form structure and data extraction

## 📋 Step-by-Step Instructions

### Step 1: Access Document Intelligence Studio (20 minutes)

#### 1.1 Navigate to Document Intelligence Studio
1. Go to [Document Intelligence Studio](https://documentintelligence.ai.azure.com/)
2. Sign in with your Azure account
3. Select your subscription and Document Intelligence resource (v4.0)

> **Note**: Ensure you're using the latest Document Intelligence Studio which supports v4.0 features including custom neural models.

#### 1.2 Explore the Interface
1. Review available prebuilt models
2. Navigate to **"Custom models"** section
3. Familiarize yourself with the studio layout

#### 1.3 Validation Checklist
- [ ] Successfully logged into Document Intelligence Studio
- [ ] Connected to your Azure resource
- [ ] Custom models section accessible
- [ ] Screenshot saved: `deliverables/screenshots/01-studio-access.png`

### Step 2: Prepare Sample Documents (30 minutes)

#### 2.1 Choose Document Type
For this learning exercise, we'll create a simple **Invoice Processor**. You can use:
- Sample invoices (recommended for learning)
- Business cards
- Forms or applications
- Receipts

#### 2.2 Collect Training Documents
You need **2-15 similar documents** for neural models with:
- Same general layout/structure (neural models handle variations better)
- Similar fields to extract
- Good image quality (clear, readable)
- Different data values (variety in content)
- Optional: Documents with signatures for signature detection testing

#### 2.3 Document Requirements
- **Format**: PDF, JPEG, PNG, BMP, TIFF
- **Size**: Up to 500 MB per file
- **Pages**: Up to 2000 pages per document
- **Quality**: Clear, well-lit, minimal skew

#### 2.4 Sample Invoice Fields to Extract
For learning purposes, we'll extract these common fields:
- Invoice Number
- Invoice Date
- Vendor Name
- Total Amount
- Customer Name
- Signature (if present - for signature detection feature)
- Line Items Table (for table confidence testing)

#### 2.5 Create Sample Documents (if needed)
If you don't have real invoices, create simple mock invoices with:
- Company letterhead
- Invoice number and date
- Customer information
- Line items
- Total amount

#### 2.6 Validation Checklist
- [ ] 5-15 similar documents collected
- [ ] Documents meet format requirements
- [ ] Fields to extract identified
- [ ] Documents organized in a folder
- [ ] Screenshot saved: `deliverables/screenshots/02-documents-prepared.png`

### Step 3: Create Custom Model Project (25 minutes)

#### 3.1 Start New Custom Model
1. In Document Intelligence Studio, click **"Custom extraction models"**
2. Click **"Create a model"**
3. Choose **"Custom neural"** (recommended for better accuracy and flexibility)

#### 3.2 Configure Model Settings
```
Model name: Week3-Invoice-Neural-Extractor
Description: Learning project for invoice data extraction using neural model
Model type: Custom neural
Build mode: Neural (for better accuracy with document variations)
```

#### 3.3 Create Storage Connection
1. You'll need an Azure Storage account for training data
2. If you don't have one, create it:
   - Go to Azure Portal
   - Create Storage Account
   - Name: `week3storage[yourname]`
   - Create a container called `training-docs`

#### 3.4 Upload Training Documents
1. Upload your sample documents to the storage container
2. In Document Intelligence Studio, connect to your storage
3. Select the container with your training documents

#### 3.5 Validation Checklist
- [ ] Custom model project created
- [ ] Storage account connected
- [ ] Training documents uploaded
- [ ] Documents visible in studio
- [ ] Screenshot saved: `deliverables/screenshots/03-project-created.png`

### Step 4: Label Training Documents (60 minutes)

#### 4.1 Start Labeling Process
1. Select your first document from the list
2. The document will appear in the labeling interface
3. You'll see the document on the left, labeling tools on the right

#### 4.2 Create Field Labels
Create labels for the fields you want to extract:
1. Click **"Add field"**
2. Create these fields:
   - `invoice_number` (type: String)
   - `invoice_date` (type: Date)
   - `vendor_name` (type: String)
   - `total_amount` (type: Number)
   - `customer_name` (type: String)
   - `signature` (type: Signature) - for signature detection
   - `line_items` (type: Table) - for table confidence testing

#### 4.3 Label First Document
For each field:
1. Select the field from the right panel
2. Click and drag to select the text in the document
3. The selected text will be highlighted and labeled
4. Repeat for all fields

#### 4.4 Label Remaining Documents
1. Move to the next document using navigation arrows
2. Label the same fields in each document
3. Ensure consistency in labeling
4. Skip documents that don't have clear field values

#### 4.5 Labeling Best Practices
- **Be Consistent**: Label the same type of information across all documents
- **Be Precise**: Select only the relevant text, avoid extra spaces
- **Skip Unclear**: Don't label fields that are unclear or missing
- **Quality over Quantity**: Better to have fewer well-labeled documents

#### 4.6 Validation Checklist
- [ ] All field types created
- [ ] At least 5 documents labeled
- [ ] Consistent labeling across documents
- [ ] All required fields labeled where present
- [ ] Screenshot saved: `deliverables/screenshots/04-labeling-complete.png`

### Step 5: Train the Custom Model (20 minutes)

#### 5.1 Start Training
1. Click **"Train"** button in the top menu
2. Review training configuration:
   - Model name: Week3-Invoice-Neural-Extractor
   - Model type: Custom neural
   - Training documents: [X] documents
   - Build mode: Neural
3. Click **"Train"** to start the process

> **Note**: Neural model training takes longer (30+ minutes) but provides better accuracy and handles document variations better than template models.

#### 5.2 Monitor Training Progress
- Neural model training typically takes 30-60 minutes
- You'll see a progress indicator with training stages
- Training status will update automatically
- You can navigate away and return later to check progress

#### 5.3 Training Completion
Once training completes, you'll see:
- Training status: Succeeded
- Model ID and version
- Training summary

#### 5.4 Validation Checklist
- [ ] Training initiated successfully
- [ ] Training completed without errors
- [ ] Model created with unique ID
- [ ] Training summary available
- [ ] Screenshot saved: `deliverables/screenshots/05-training-complete.png`

### Step 6: Test the Custom Model (35 minutes)

#### 6.1 Prepare Test Document
- Use a document NOT in your training set
- Should be similar format to training documents
- Contains the fields you trained the model to extract

#### 6.2 Run Model Test
1. Click **"Test"** in the studio
2. Upload your test document
3. Select your trained model
4. Click **"Run analysis"**

#### 6.3 Review Extraction Results
The results will show:
- **Extracted fields** with values
- **Confidence scores** for each extraction (improved with neural models)
- **Bounding boxes** showing where data was found
- **Table confidence scores** for table, row, and cell levels
- **Signature detection results** (if signatures present)
- **Overlapping field handling** (neural model capability)

#### 6.4 Analyze Model Performance
For each extracted field, note:
- **Field name**: What was extracted
- **Extracted value**: The actual text found
- **Expected value**: What should have been extracted
- **Confidence score**: Model's confidence (0-1)
- **Accuracy**: Correct/Incorrect

#### 6.5 Document Test Results
```markdown
# Custom Model Test Results

## Test Document: [filename]

### Extraction Results
| Field | Extracted Value | Expected Value | Confidence | Correct |
|-------|----------------|----------------|------------|---------|
| invoice_number | [value] | [expected] | [0.XX] | [Yes/No] |
| invoice_date | [value] | [expected] | [0.XX] | [Yes/No] |
| vendor_name | [value] | [expected] | [0.XX] | [Yes/No] |
| total_amount | [value] | [expected] | [0.XX] | [Yes/No] |
| customer_name | [value] | [expected] | [0.XX] | [Yes/No] |
| signature | [detected/not detected] | [expected] | [0.XX] | [Yes/No] |
| line_items | [table extracted] | [expected] | [0.XX] | [Yes/No] |

### Summary
- Total fields: 7 (including signature and table)
- Correctly extracted: [X]
- Accuracy: [X]%
- Average confidence: [X.XX]
- Signature detection: [Success/Failed]
- Table extraction quality: [Good/Fair/Poor]
```

#### 6.6 Validation Checklist
- [ ] Test document analyzed
- [ ] Extraction results reviewed
- [ ] Confidence scores noted
- [ ] Accuracy calculated
- [ ] Test results documented
- [ ] Screenshot saved: `deliverables/screenshots/06-test-results.png`

## 📊 Deliverables

Save all deliverables in `docs/week3/deliverables/document-intelligence-model/`:

### Required Files
1. **`model-configuration.md`** - Model setup and configuration details
2. **`labeling-summary.md`** - Summary of labeling process and decisions
3. **`test-results.md`** - Test results and performance analysis
4. **`training-summary.md`** - Overall training experience

### Screenshots
1. `01-studio-access.png` - Document Intelligence Studio access
2. `02-documents-prepared.png` - Training documents prepared
3. `03-project-created.png` - Custom model project created
4. `04-labeling-complete.png` - Document labeling completed
5. `05-training-complete.png` - Model training completed
6. `06-test-results.png` - Model test results

### Model Configuration Template
```markdown
# Document Intelligence Custom Model Configuration

## Model Details
- Model Name: Week3-Invoice-Neural-Extractor
- Model Type: Custom neural
- Build Mode: Neural
- Creation Date: [Date]
- Model ID: [Generated ID]
- API Version: 2024-11-30 (v4.0 GA)

## Training Dataset
- Document Type: Invoices
- Number of Documents: [X]
- Document Formats: [PDF/JPEG/PNG]
- Storage Location: [Container name]

## Extracted Fields
1. **invoice_number** (String)
   - Description: Unique invoice identifier
   - Expected format: [Format description]

2. **invoice_date** (Date)
   - Description: Date invoice was issued
   - Expected format: [Date format]

3. **vendor_name** (String)
   - Description: Name of the vendor/company
   - Expected format: [Text description]

4. **total_amount** (Number)
   - Description: Total invoice amount
   - Expected format: [Currency format]

5. **customer_name** (String)
   - Description: Customer or client name
   - Expected format: [Text description]

6. **signature** (Signature)
   - Description: Signature detection field
   - Expected format: Signature present/absent

7. **line_items** (Table)
   - Description: Invoice line items table
   - Expected format: Structured table data

## Training Process
- Labeling time: [X] minutes
- Training time: [X] minutes
- Training status: [Success/Failed]
- Challenges encountered: [List any issues]
```

## ✅ Success Criteria

- [ ] Document Intelligence Studio accessed successfully
- [ ] Custom model project created
- [ ] Minimum 5 documents labeled consistently
- [ ] Model trained without errors
- [ ] Test performed with new document
- [ ] Neural model achieves good accuracy (70%+ field extraction)
- [ ] Signature detection tested (if applicable)
- [ ] Table extraction evaluated with confidence scores
- [ ] All deliverables completed and documented
- [ ] Screenshots captured for all major steps

## 🚨 Troubleshooting

### Common Issues

**Can't Access Studio**
- Verify Document Intelligence resource is deployed
- Check Azure subscription permissions
- Try incognito/private browsing mode

**Training Fails**
- Check document formats (PDF, JPEG, PNG, BMP, TIFF only)
- Ensure documents are readable and clear
- Verify storage account permissions

**Low Extraction Accuracy**
- Review labeling consistency across documents
- Ensure sufficient training documents (5+ minimum)
- Check document quality and clarity
- Verify field labels are precise

**Storage Connection Issues**
- Verify storage account exists and is accessible
- Check container permissions
- Ensure documents are uploaded to correct container

### Getting Help
- Review [Document Intelligence Documentation](https://learn.microsoft.com/azure/ai-services/document-intelligence/)
- Check Azure portal for service status
- Verify resource quotas and limits

## 🎓 Learning Questions

After completing this task, reflect on:

1. **Data Quality**: How did document quality affect extraction accuracy?
2. **Labeling Consistency**: What happened when labeling was inconsistent?
3. **Field Types**: How did different field types (string, date, number) perform?
4. **Confidence Scores**: What do confidence scores tell you about extraction reliability?
5. **Real-world Applications**: Where could you use custom document intelligence?

## ➡️ Next Steps

Proceed to [Task 3: Azure OpenAI Fine-tuning](task3-openai-finetuning.md) to learn about fine-tuning language models with custom data.

---

**💡 Pro Tip**: Consistent, high-quality labeling is crucial for good document extraction. Take time to label precisely and consistently across all training documents! 